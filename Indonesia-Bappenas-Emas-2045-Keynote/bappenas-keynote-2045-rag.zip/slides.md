# Keynote Speech Musrenbangnas dalam rangka Penyusunan RPJPN 2025-2045

Menteri Perencanaan Pembangunan Nasional / Kepala Bappenas — Musyawarah Perencanaan Pembangunan Nasional (Musrenbangnas) 2023, Bali, Indonesia, 2023-05-22

> Watermark on every slide: 'Tidak untuk Dikutip' (not for citation) - www.indonesia2045.go.id


---

## PDF p.1 — Musrenbangnas dalam Rangka Penyusunan RPJPN 2025-2045 - Keynote Speech

*EN: Musrenbangnas for the Preparation of RPJPN 2025-2045 - Keynote Speech*  
`type: cover` `section: front_matter`

**Summary (EN):** Cover of the keynote speech delivered by the Minister of National Development Planning / Head of Bappenas at the 2023 National Development Planning Conference (Musrenbangnas) in Bali on 22 May 2023, held to prepare the National Long-Term Development Plan (RPJPN) 2025-2045.

**Teks slide (ID):**

```
MUSRENBANGNAS DALAM RANGKA PENYUSUNAN RPJPN 2025-2045
Keynote Speech
Menteri Perencanaan Pembangunan Nasional/ Kepala Badan Perencanaan Pembangunan Nasional
Bali, 22 Mei 2023
```

**Deskripsi visual (ID):** Slide sampul dengan latar siluet kota dan bendera merah putih; logo Bappenas, Indonesia Emas 2045, dan ASEAN Indonesia 2023 di bagian atas.

**Visual description (EN):** Cover slide with a city skyline silhouette and the red-and-white flag; Bappenas, Indonesia Emas 2045 and ASEAN Indonesia 2023 logos at the top.


---

## PDF p.2 (slide 2) — Telah Banyak Pencapaian yang Diraih selama 10 Tahun Terakhir Pembangunan (2014-2022)...

*EN: Many Achievements Have Been Attained over the Last 10 Years of Development (2014-2022)*  
`type: text` `section: achievements_2014_2022`

**Summary (EN):** Summarises Indonesia's key development achievements 2014-2022: bureaucratic reform (e-government SPBE, public service malls, simplified business licensing) lifting the Ease of Doing Business rank from 103 (2015) to 73 (2020); social welfare programmes (KIP, KIS, BPJS) cutting stunting from 29% (2015) to 21.6% (2022); nickel downstreaming raising local economies from about USD 800 million (2015) to USD 6 billion (2022); 10 priority tourism destinations lifting foreign tourist visits from 9.44 million (2014) to 16.11 million (2019); the one-price fuel policy since 1 January 2017; relocation of the capital to Nusantara (IKN) as an economic super hub to reduce the western-eastern Indonesia gap; and land registration reaching 85.6 million certificates.

**Teks slide (ID):**

```
Perkuatan Reformasi Birokrasi
Penggunaan teknologi dalam pelayanan publik:
- SPBE
- Mall Pelayanan Publik
- Penyederhanaan Perizinan Usaha
Sehingga, peringkat EODB meningkat pesat dari 103 (2015) menjadi 73 (2020)

Perkuatan program kesejahteraan sosial masyarakat
Melalui:
- Kartu Indonesia Pintar (KIP) dan Kartu Indonesia Sehat (KIS)
- Penguatan program BPJS Kesehatan dan Ketenagakerjaan serta dukungan fasilitas kesehatan yang diperlukan
- Percepatan penanganan stunting sehingga prevalensinya menurun dari 29% (2015) menjadi 21,6% (2022)

Hilirisasi Sumber Daya Mineral (nikel)
- Mengurangi eksploitasi sumber daya yang merusak lingkungan.
- Hilirisasi nikel menghasilkan investasi yang besar di Kawasan industri di Luar Jawa.
- Perekonomian lokal meningkat pesat dari kisaran USD 800 Juta (2015) menjadi USD 6 Miliar (2022).

Penataan Destinasi Pariwisata Prioritas (DPP)
- Menggalakkan investasi dalam infrastruktur pariwisata dan mempromosikan 10 DPP sebagai destinasi wisata baru.
- Jumlah wisatawan mancanegara semula hanya 9,44 juta kunjungan (2014), melonjak menjadi 16,11 juta kunjungan (2019) sebelum terjadi Covid-19 tahun 2020.

Penerapan Kebijakan BBM satu harga
Yang berlaku sejak 1 Januari 2017 telah mengurangi perbedaan harga di seluruh Indonesia, terutama di daerah perbatasan dan mendorong pertumbuhan ekonomi yang lebih merata

Pemindahan Ibu Kota Nusantara (IKN)
- Untuk mengurangi ketimpangan antara KBI dan KTI, menyongsong tatanan baru, cara kerja baru, dan mendorong Transformasi Ekonomi Indonesia ke depan.
- Pemindahan Ibu Kota ini tidak hanya memindahkan aktivitas pemerintahan, tetapi juga membangun pusat pertumbuhan ekonomi baru yang disebut super hub ekonomi IKN

Percepatan pendaftaran tanah di seluruh tanah air
- Untuk meningkatkan kepastian hukum hak atas tanah, termasuk bagi masyarakat miskin yang memiliki tanah namun belum bersertifikat,
- Percepatan pelaksanaan program sertifikasi tanah, sehingga total sertifikat tanah yang sudah dibagikan kepada masyarakat mencapai 85,6 juta sertifikat.

Sumber: Rancangan Awal RPJPN 2025-2045
```

**Deskripsi visual (ID):** Dua kolom berisi tujuh capaian pembangunan 2014-2022, masing-masing dengan ikon (dokumen/centang, hati, pabrik, pantai, pompa BBM, peta Kalimantan, pin lokasi).

**Visual description (EN):** Two-column layout listing seven development achievements 2014-2022, each with an icon (checklist, heart, factory, beach, fuel pump, map of Kalimantan, map pin).

**Structured data:**

```json
{
  "achievements_2014_2022": [
    {
      "area": "Reformasi Birokrasi",
      "indicator": "Peringkat EODB (Ease of Doing Business)",
      "from": {
        "value": 103,
        "year": 2015
      },
      "to": {
        "value": 73,
        "year": 2020
      }
    },
    {
      "area": "Kesejahteraan sosial",
      "indicator": "Prevalensi stunting",
      "from": {
        "value": 29.0,
        "unit": "%",
        "year": 2015
      },
      "to": {
        "value": 21.6,
        "unit": "%",
        "year": 2022
      }
    },
    {
      "area": "Hilirisasi nikel",
      "indicator": "Perekonomian lokal (nilai)",
      "from": {
        "value": 0.8,
        "unit": "USD billion",
        "year": 2015
      },
      "to": {
        "value": 6.0,
        "unit": "USD billion",
        "year": 2022
      }
    },
    {
      "area": "Pariwisata (10 DPP)",
      "indicator": "Kunjungan wisatawan mancanegara",
      "from": {
        "value": 9.44,
        "unit": "million visits",
        "year": 2014
      },
      "to": {
        "value": 16.11,
        "unit": "million visits",
        "year": 2019
      },
      "note": "before Covid-19 in 2020"
    },
    {
      "area": "BBM satu harga",
      "indicator": "Kebijakan berlaku sejak",
      "value": "2017-01-01"
    },
    {
      "area": "IKN",
      "indicator": "Tujuan",
      "value": "mengurangi ketimpangan KBI-KTI; super hub ekonomi IKN"
    },
    {
      "area": "Pendaftaran tanah",
      "indicator": "Total sertifikat tanah dibagikan",
      "value": 85.6,
      "unit": "million certificates"
    }
  ]
}
```

**Relationships:**
- Reformasi birokrasi (SPBE, MPP, penyederhanaan perizinan) -> peringkat EODB naik 103 -> 73
- Program kesejahteraan sosial (KIP, KIS, BPJS) -> stunting turun 29% -> 21.6%
- Hilirisasi nikel -> investasi kawasan industri luar Jawa -> ekonomi lokal USD 0.8 miliar -> USD 6 miliar
- Pemindahan IKN -> mengurangi ketimpangan KBI-KTI


---

## PDF p.3 (slide 3) — Tantangan Global ke Depan Semakin Kompleks Mengikuti Perubahan yang Sangat Cepat di Segala Bidang

*EN: Future Global Challenges Are Increasingly Complex, Following Very Rapid Change in All Fields*  
`type: diagram` `section: global_challenges`

**Summary (EN):** Presents the ten 'Megatrends 2045' that will shape the global development paradigm over the next 20 years: geopolitics/geoeconomics (developing countries reaching 71% of global output), a middle class exceeding 90% of population (8.8 billion), competition for natural resources, climate change, a shift from US-dollar dominance to multiple currencies, the space economy, urbanisation (65% urban, 70% of GDP), global trade growing 3.4% a year, technology replacing about 40% of current jobs, and a world population of 9.45 billion with a rising elderly share (55% in Asia).

**Teks slide (ID):**

```
Megatren global yang penting dalam 20 tahun ke depan akan merubah paradigma pembangunan global, mendorong kebijakan pro-lingkungan, adaptasi teknologi, pembangunan infrastruktur konektivitas kawasan yang lebih hijau, serta penggunaan sistem keuangan digital.

Megatren 2045:
- Geopolitik dan Geoekonomi: Eskalasi persaingan antarnegara dan kemunculan kekuatan baru. Nilai output negara berkembang mencapai 71%
- Penduduk Kelas Menengah: Jumlah middle dan upper income class lebih dari 90% (8,8 miliar)
- Persaingan Sumber Daya Alam: Peningkatan peranan ekonomi Asia dan penduduk di Afrika mendorong persaingan memperebutkan SDA
- Perubahan Iklim: Peningkatan suhu global disertai cuaca ekstrem dan bencana
- Keuangan Internasional: Dominasi mata uang dunia bergeser dari dolar AS menjadi multi currencies
- Luar Angkasa: Ekonomi Antariksa; Kelestarian Antariksa; Keamanan Antariksa
- Urbanisasi Dunia: Penduduk perkotaan 65%; Peranan Produk Domestik Bruto (PDB) 70%
- Perdagangan Internasional: Perdagangan global tumbuh 3,4% per tahun
- Disrupsi Teknologi: Teknologi akan menggantikan sekitar 40% pekerjaan saat ini
- Demografi Global: Penduduk dunia menjadi 9,45 miliar dan porsi lansia meningkat (Asia 55%)

Sumber: Rancangan Awal RPJPN 2025-2045
```

**Deskripsi visual (ID):** Diagram roda/lingkaran berjudul 'Megatren 2045' dengan 10 segmen berwarna, masing-masing berikon, dikelilingi label dan penjelasan singkat setiap megatren. Kotak biru di kiri berisi narasi pengantar.

**Visual description (EN):** Wheel diagram titled 'Megatren 2045' with 10 coloured segments, each with an icon, surrounded by the label and one-line explanation of each megatrend. A blue box on the left holds the introductory narrative.

**Structured data:**

```json
{
  "megatrends_2045": [
    {
      "name_id": "Geopolitik dan Geoekonomi",
      "name_en": "Geopolitics and geoeconomics",
      "metric": "developing countries' share of global output 71%"
    },
    {
      "name_id": "Penduduk Kelas Menengah",
      "name_en": "Middle-class population",
      "metric": "middle + upper income class > 90% (8.8 billion people)"
    },
    {
      "name_id": "Persaingan Sumber Daya Alam",
      "name_en": "Competition for natural resources",
      "metric": null
    },
    {
      "name_id": "Perubahan Iklim",
      "name_en": "Climate change",
      "metric": null
    },
    {
      "name_id": "Keuangan Internasional",
      "name_en": "International finance",
      "metric": "shift from US dollar dominance to multi-currencies"
    },
    {
      "name_id": "Luar Angkasa",
      "name_en": "Outer space",
      "metric": "space economy, sustainability, security"
    },
    {
      "name_id": "Urbanisasi Dunia",
      "name_en": "Global urbanisation",
      "metric": "urban population 65%; share of GDP 70%"
    },
    {
      "name_id": "Perdagangan Internasional",
      "name_en": "International trade",
      "metric": "global trade growth 3.4% per year"
    },
    {
      "name_id": "Disrupsi Teknologi",
      "name_en": "Technological disruption",
      "metric": "about 40% of current jobs replaced by technology"
    },
    {
      "name_id": "Demografi Global",
      "name_en": "Global demography",
      "metric": "world population 9.45 billion; rising elderly share (Asia 55%)"
    }
  ]
}
```

**Relationships:**
- Megatren 2045 (10 tren) -> mengubah paradigma pembangunan global -> kebijakan pro-lingkungan, adaptasi teknologi, konektivitas hijau, keuangan digital


---

## PDF p.4 (slide 4) — ...Dan Indonesia Memiliki Modal Dasar Pembangunan dalam Menghadapi Berbagai Tantangan ke Depan

*EN: ...And Indonesia Has Basic Development Capital to Face the Various Challenges Ahead*  
`type: chart` `section: development_capital`

**Summary (EN):** Indonesia's basic development capital: a large productive population, cultural diversity and mutual cooperation (gotong royong), natural resources, biodiversity and maritime wealth. Population is projected to reach about 324 million in 2045 (6th in the world), growing from 269.58 million (2020) to 328.93 million (2050) while the growth rate falls from 1.08% (2025) to 0.30% (2050). The working-age share (15-64) declines slowly from 69.28% (2020) to 65.79% (2045), while the 65+ share rises from 6.16% to 14.61%. Socio-cultural capital (harmony, tolerance, consensus, solidarity, self-reliance) and human capital attributes (prosperous, adaptive, noble character, advanced culture, excellent, competitive) are listed.

**Teks slide (ID):**

```
Modal dasar pembangunan yang dimiliki oleh Indonesia akan menjadi kekuatan dan landasan penting untuk membangun bangsa, antara lain:
- Jumlah penduduk yang besar dengan tenaga kerja produktif yang melimpah,
- Keberagaman budaya dan asas gotong royong,
- Sumber daya alam dan
- Keanekaragaman hayati, serta
- Kekayaan maritim.

Kependudukan
Pada tahun 2045 Populasi Indonesia sekitar 324 Juta dan menempati posisi 6 dunia
[Grafik: Jumlah Penduduk (juta jiwa) dan Laju Pertumbuhan Penduduk (%)]

Bonus Demografi
Penduduk usia produktif berperan penting sebagai pelaku utama pembangunan dan pendorong pertumbuhan ekonomi
[Grafik: struktur umur 0-14 Tahun, 15-64 Tahun, 65+ Tahun]

Modal Sosial Budaya
- Guyub, rukun, dan toleran
- Gotong Royong
- Musyawarah mufakat
- Kekeluargaan
- Solidaritas sosial dan kesukarelawanan
- Berjiwa berdikari
- Keragaman Budaya

Modal Manusia
- Sejahtera
- Adaptif
- Berakhlak mulia
- Berbudaya maju
- Unggul
- Berdaya saing

Sumber: Rancangan Awal RPJPN 2025-2045
```

**Deskripsi visual (ID):** Grafik batang proyeksi jumlah penduduk 2020-2050 (juta jiwa) dengan garis laju pertumbuhan penduduk (%) yang menurun; tahun 2045 diberi kotak merah. Di kanan, grafik batang bertumpuk horizontal struktur umur penduduk 2020-2050 (0-14, 15-64, 65+ dalam %). Dua gelembung teks berisi modal sosial budaya dan modal manusia.

**Visual description (EN):** Bar chart of projected population 2020-2050 (millions) with a declining line for population growth rate (%); 2045 is highlighted with a red box. On the right, a horizontal stacked bar chart of age structure 2020-2050 (0-14, 15-64, 65+ in %). Two speech bubbles list socio-cultural capital and human capital attributes.

**Structured data:**

```json
{
  "population_projection": {
    "unit_population": "million people",
    "unit_growth": "% per year",
    "rows": [
      {
        "year": 2020,
        "population": 269.58,
        "growth_rate": null
      },
      {
        "year": 2025,
        "population": 284.44,
        "growth_rate": 1.08
      },
      {
        "year": 2030,
        "population": 297.43,
        "growth_rate": 0.9
      },
      {
        "year": 2035,
        "population": 308.37,
        "growth_rate": 0.72
      },
      {
        "year": 2040,
        "population": 317.23,
        "growth_rate": 0.57
      },
      {
        "year": 2045,
        "population": 324.05,
        "growth_rate": 0.43
      },
      {
        "year": 2050,
        "population": 328.93,
        "growth_rate": 0.3
      }
    ],
    "note": "2045 population ~324 million, 6th largest in the world"
  },
  "age_structure_pct": {
    "columns": [
      "year",
      "age_0_14",
      "age_15_64",
      "age_65_plus"
    ],
    "rows": [
      [
        2020,
        24.56,
        69.28,
        6.16
      ],
      [
        2025,
        23.46,
        68.95,
        7.59
      ],
      [
        2030,
        22.45,
        68.28,
        9.27
      ],
      [
        2035,
        21.51,
        67.42,
        11.07
      ],
      [
        2040,
        20.41,
        66.71,
        12.88
      ],
      [
        2045,
        19.61,
        65.79,
        14.61
      ],
      [
        2050,
        19.09,
        64.88,
        16.03
      ]
    ]
  },
  "modal_sosial_budaya": [
    "Guyub, rukun, dan toleran",
    "Gotong Royong",
    "Musyawarah mufakat",
    "Kekeluargaan",
    "Solidaritas sosial dan kesukarelawanan",
    "Berjiwa berdikari",
    "Keragaman Budaya"
  ],
  "modal_manusia": [
    "Sejahtera",
    "Adaptif",
    "Berakhlak mulia",
    "Berbudaya maju",
    "Unggul",
    "Berdaya saing"
  ]
}
```

**Relationships:**
- Modal dasar (penduduk, budaya, SDA, hayati, maritim) -> landasan membangun bangsa
- Penduduk usia produktif -> pelaku utama pembangunan dan pendorong pertumbuhan


---

## PDF p.5 (slide 5) — Pendekatan untuk Membangun Indonesia Masa Depan Harus Berubah.....

*EN: The Approach to Building Indonesia's Future Must Change*  
`type: concept` `section: approach_shift`

**Summary (EN):** Frames the paradigm shift of the RPJPN 2025-2045: Indonesia's development approach must move from 'reform' (improving the existing form) to 'transformation' (changing form fundamentally), illustrated by caterpillar-to-butterfly metamorphosis.

**Teks slide (ID):**

```
From Re-Form -> To Trans-Form
Reform is to put into a new and improved form or condition
Transform is to change greatly the appearance or form

Sumber: Rancangan Awal RPJPN 2025-2045
```

**Deskripsi visual (ID):** Ilustrasi metamorfosis ulat menjadi kepompong lalu kupu-kupu di atas; di bawahnya kata 'Re-Form' (oranye) dengan panah ke 'Trans-Form' (hijau), masing-masing dengan definisi bahasa Inggris.

**Visual description (EN):** Illustration of a caterpillar turning into a chrysalis and then butterflies; below, the word 'Re-Form' (orange) with an arrow to 'Trans-Form' (green), each with an English definition.

**Relationships:**
- Pendekatan pembangunan bergeser dari reform (perbaikan bertahap) ke transform (perubahan besar)


---

## PDF p.6 (slide 6) — Visi Indonesia Emas 2045: Negara Nusantara Berdaulat, Maju, dan Berkelanjutan

*EN: Vision of Golden Indonesia 2045: A Sovereign, Advanced and Sustainable Archipelagic State*  
`type: diagram` `section: vision_2045`

**Summary (EN):** States the Vision of Golden Indonesia 2045: 'Negara Nusantara' - an archipelagic state with political, economic, national-security and maritime-civilisation resilience as a global maritime axis - that is Sovereign (resilient, united, independent, secure), Advanced (empowered, modern, resilient, innovative, just) and Sustainable (balanced economic, social and environmental development).

**Teks slide (ID):**

```
Negara Nusantara
Negara kepulauan yang memiliki ketangguhan politik, ekonomi, keamanan nasional, dan budaya/peradaban bahari sebagai poros maritim dunia

Berdaulat: Ketahanan, Kesatuan, Mandiri, Aman
Maju: Berdaya, Modern, Tangguh, Inovatif, Adil
Berkelanjutan: Lestari dan seimbang antara pembangunan ekonomi, sosial, dan lingkungan

Sumber: Rancangan Awal RPJPN 2025-2045
```

**Deskripsi visual (ID):** Peta Indonesia 3D berwarna kuning-hijau di atas; di bawahnya garis bercabang tiga ke ilustrasi kapal perang (Berdaulat), manusia dengan robot/teknologi (Maju), dan energi terbarukan (Berkelanjutan).

**Visual description (EN):** 3D yellow-green map of Indonesia at the top; a three-way branch below leads to illustrations of naval ships (Sovereign), people with robots/technology (Advanced), and renewable energy (Sustainable).

**Structured data:**

```json
{
  "vision_2045": {
    "headline_id": "Negara Nusantara Berdaulat, Maju, dan Berkelanjutan",
    "pillars": [
      {
        "id": "Berdaulat",
        "en": "Sovereign",
        "attributes_id": [
          "Ketahanan",
          "Kesatuan",
          "Mandiri",
          "Aman"
        ]
      },
      {
        "id": "Maju",
        "en": "Advanced",
        "attributes_id": [
          "Berdaya",
          "Modern",
          "Tangguh",
          "Inovatif",
          "Adil"
        ]
      },
      {
        "id": "Berkelanjutan",
        "en": "Sustainable",
        "attributes_id": [
          "Lestari dan seimbang antara pembangunan ekonomi, sosial, dan lingkungan"
        ]
      }
    ]
  }
}
```

**Relationships:**
- Visi Indonesia Emas 2045 = Negara Nusantara -> 3 pilar: Berdaulat, Maju, Berkelanjutan


---

## PDF p.7 (slide 6) — Visi Indonesia Emas 2045: Negara Nusantara Berdaulat, Maju, dan Berkelanjutan

*EN: Vision of Golden Indonesia 2045 (duplicate of page 6)*  
`type: duplicate` `section: vision_2045`

Duplicate of bappenas-keynote-2045-p06.

---

## PDF p.8 (slide 7) — ...Sehingga, dibutuhkan Strategi Besar untuk Mencapai Visi Indonesia....

*EN: ...Therefore, a Grand Strategy Is Needed to Achieve Indonesia's Vision*  
`type: diagram` `section: grand_strategy`

**Summary (EN):** Introduces the '8/17/45 Grand Strategy based on Pancasila' that structures the RPJPN 2025-2045: the eternal national vision (independent, united, sovereign, just, prosperous) and internal factors (basic capital, past achievements) plus external factors (Megatrends 2045, geopolitics) feed the Vision Indonesia Emas 2025-2045, which cascades into 5 vision targets, 8 development missions, 17 development directions and 45 main development indicators. The numbers 5/17/45 echo the five Pancasila principles and the 17 August 1945 independence date, with 2045 marking 100 years of independence; the 8 missions map to the four eternal state missions in the 1945 Constitution preamble.

**Teks slide (ID):**

```
STRATEGI BESAR: 8/17/45 BERLANDASKAN PANCASILA

VISI ABADI INDONESIA: Merdeka, Bersatu, berdaulat, adil, dan makmur

Faktor Internal
I. Modal Dasar
- Kependudukan
- Modal Manusia
- Modal Sosial dan Budaya
- Kekayaan Alam
- Kekuatan Negara Kepulauan
II. Capaian Pembangunan

Faktor Eksternal
- Megatren 2045
- Geopolitik dan Geoekonomi

VISI INDONESIA EMAS 2025-2045
5 Sasaran Visi Indonesia 2025-2045
8 MISI PEMBANGUNAN
17 ARAH PEMBANGUNAN
45 INDIKATOR UTAMA PEMBANGUNAN

MAKNA: 5 Pancasila; 100 tahun Indonesia Merdeka; 17-8-2045

MISI Abadi Bernegara:
1. Melindungi segenap bangsa Indonesia dan seluruh tumpah darah Indonesia
2. Memajukan kesejahteraan umum,
3. Mencerdaskan kehidupan bangsa
4. Ikut melaksanakan ketertiban dunia yang berdasarkan kemerdekaan, perdamaian abadi dan keadilan sosial

Sumber: Rancangan Awal RPJPN 2025-2045
```

**Deskripsi visual (ID):** Diagram alur vertikal: Visi Abadi Indonesia (merah) di puncak, dipengaruhi Faktor Internal (kiri) dan Faktor Eksternal (kanan), turun ke Visi Indonesia Emas 2025-2045 dan 5 Sasaran (kotak putus-putus), lalu ke 8 Misi Pembangunan, 17 Arah Pembangunan, dan 45 Indikator Utama Pembangunan. Kotak 'MAKNA' menjelaskan angka 5/17/45 (5 Pancasila, 17-8-2045 = 100 tahun merdeka). 8 Misi dihubungkan dengan 4 Misi Abadi Bernegara (pembukaan UUD 1945).

**Visual description (EN):** Vertical flow diagram: the Eternal Vision of Indonesia (red) at the top, fed by Internal Factors (left) and External Factors (right), flowing down to the Vision Indonesia Emas 2025-2045 and its 5 Targets (dashed box), then to 8 Development Missions, 17 Development Directions and 45 Main Development Indicators. A 'MAKNA' (meaning) box explains the numbers: 5 = Pancasila principles, 17-8-2045 = 100 years of independence. The 8 missions are linked to the 4 eternal state missions from the 1945 Constitution preamble.

**Structured data:**

```json
{
  "grand_strategy_8_17_45": {
    "name": "Strategi Besar 8/17/45 berlandaskan Pancasila",
    "hierarchy": [
      "Visi Abadi Indonesia",
      "Visi Indonesia Emas 2025-2045",
      "5 Sasaran Visi",
      "8 Misi Pembangunan",
      "17 Arah Pembangunan",
      "45 Indikator Utama Pembangunan"
    ],
    "numerology": {
      "5": "sila Pancasila / 5 sasaran",
      "17": "17 Agustus / 17 arah",
      "45": "1945 / 45 indikator",
      "2045": "100 tahun Indonesia merdeka (17-8-2045)"
    },
    "internal_factors": {
      "modal_dasar": [
        "Kependudukan",
        "Modal Manusia",
        "Modal Sosial dan Budaya",
        "Kekayaan Alam",
        "Kekuatan Negara Kepulauan"
      ],
      "capaian_pembangunan": true
    },
    "external_factors": [
      "Megatren 2045",
      "Geopolitik dan Geoekonomi"
    ],
    "misi_abadi_bernegara": [
      "Melindungi segenap bangsa Indonesia dan seluruh tumpah darah Indonesia",
      "Memajukan kesejahteraan umum",
      "Mencerdaskan kehidupan bangsa",
      "Ikut melaksanakan ketertiban dunia yang berdasarkan kemerdekaan, perdamaian abadi dan keadilan sosial"
    ]
  }
}
```

**Relationships:**
- Faktor Internal (modal dasar, capaian) + Faktor Eksternal (megatren, geopolitik) -> Visi Indonesia Emas 2025-2045
- Visi Indonesia Emas 2025-2045 -> 5 Sasaran Visi -> 8 Misi Pembangunan -> 17 Arah Pembangunan -> 45 Indikator Utama Pembangunan
- 8 Misi Pembangunan <-> 4 Misi Abadi Bernegara (Pembukaan UUD 1945)


---

## PDF p.9 (slide 8) — 5 Sasaran Visi Indonesia Emas 2045...

*EN: The 5 Targets of the Vision Indonesia Emas 2045*  
`type: infographic` `section: vision_targets`

**Summary (EN):** The five targets of Vision Indonesia Emas 2045 with 2025 baselines: (1) per-capita income at developed-country level - GNI per capita from USD 5,550 to USD 30,300, maritime GDP share 7.6% to 17.5%, industry GDP share 18.7% to 28.0%; (2) poverty toward zero and lower inequality - poverty rate 6.5-7.5% to 0.5-0.8%, Gini ratio 0.379-0.382 (2022) to 0.290-0.320, eastern Indonesia (KTI) share of GDP 20.6% (2022) to 26.0%; (3) greater international leadership - Global Power Index rank 34 (2023) to top 15; (4) human-resource competitiveness - Human Capital Index 0.54 (2022) to 0.73; (5) GHG emission intensity toward net zero - reduction from 38.6% to 93.5%.

**Teks slide (ID):**

```
INDONESIA 2045
1. Pendapatan per Kapita Setara Negara Maju
- GNI per kapita: USD 30.300
- Kontribusi PDB Maritim: 17,5%
- Kontribusi PDB Industri: 28,0%
2. Kemiskinan Menuju 0% dan Ketimpangan Berkurang
- Tingkat Kemiskinan: 0,5-0,8%
- Rasio Gini: 0,290 - 0,320
- Kontribusi KTI terhadap PDB: 26,0%
3. Kepemimpinan dan Pengaruh di Dunia Internasional meningkat
- Global Power Index: 15 Besar
4. Daya Saing Sumber Daya Manusia Meningkat
- HCI: 0,73
5. Intensitas Emisi GRK Menuju Net Zero Emission
- Penurunan: 93,5%

INDONESIA 2025
1. Pendapatan per Kapita Menengah Atas
- GNI per kapita: USD 5.550
- Kontribusi PDB Maritim: 7,6%
- Kontribusi PDB Industri: 18,7%
2. Kemiskinan dan Ketimpangan
- Tingkat Kemiskinan: 6,5-7,5%
- Rasio Gini: 0,379-0,382 (2022)
- Kontribusi KTI terhadap PDB: 20,6% (2022)
3. Kepemimpinan dan Pengaruh di Dunia Internasional
- Global Power Index: 34 (2023)
4. Daya Saing Sumber Daya Manusia
- HCI: 0,54 (2022)
5. Intensitas Emisi GRK
- Penurunan: 38,6%
```

**Deskripsi visual (ID):** Ilustrasi gunung dengan bendera di puncak; panah biru naik dari 'Indonesia 2025' (bawah) ke 'Indonesia 2045' (atas). Lima sasaran ditampilkan sebagai kotak bernomor 1-5 dengan nilai baseline 2025 dan target 2045.

**Visual description (EN):** Mountain illustration with a flag on the summit; a blue arrow rises from 'Indonesia 2025' (bottom) to 'Indonesia 2045' (top). The five targets appear as numbered boxes 1-5 with 2025 baseline values and 2045 targets.

**Structured data:**

```json
{
  "five_vision_targets": [
    {
      "no": 1,
      "target_id": "Pendapatan per Kapita Setara Negara Maju",
      "target_en": "Per-capita income on par with developed countries",
      "indicators": [
        {
          "name": "GNI per kapita",
          "unit": "USD",
          "baseline_2025": 5550,
          "target_2045": 30300
        },
        {
          "name": "Kontribusi PDB Maritim",
          "unit": "%",
          "baseline_2025": 7.6,
          "target_2045": 17.5
        },
        {
          "name": "Kontribusi PDB Industri",
          "unit": "%",
          "baseline_2025": 18.7,
          "target_2045": 28.0
        }
      ]
    },
    {
      "no": 2,
      "target_id": "Kemiskinan Menuju 0% dan Ketimpangan Berkurang",
      "target_en": "Poverty toward 0% and reduced inequality",
      "indicators": [
        {
          "name": "Tingkat Kemiskinan",
          "unit": "%",
          "baseline_2025": "6.5-7.5",
          "target_2045": "0.5-0.8"
        },
        {
          "name": "Rasio Gini",
          "unit": "index",
          "baseline_2025": "0.379-0.382 (2022)",
          "target_2045": "0.290-0.320"
        },
        {
          "name": "Kontribusi KTI terhadap PDB",
          "unit": "%",
          "baseline_2025": "20.6 (2022)",
          "target_2045": 26.0
        }
      ]
    },
    {
      "no": 3,
      "target_id": "Kepemimpinan dan Pengaruh di Dunia Internasional meningkat",
      "target_en": "Increased international leadership and influence",
      "indicators": [
        {
          "name": "Global Power Index",
          "unit": "rank",
          "baseline_2025": "34 (2023)",
          "target_2045": "top 15"
        }
      ]
    },
    {
      "no": 4,
      "target_id": "Daya Saing Sumber Daya Manusia Meningkat",
      "target_en": "Increased human-resource competitiveness",
      "indicators": [
        {
          "name": "HCI (Human Capital Index)",
          "unit": "index",
          "baseline_2025": "0.54 (2022)",
          "target_2045": 0.73
        }
      ]
    },
    {
      "no": 5,
      "target_id": "Intensitas Emisi GRK Menuju Net Zero Emission",
      "target_en": "GHG emission intensity toward net zero",
      "indicators": [
        {
          "name": "Penurunan intensitas emisi GRK",
          "unit": "%",
          "baseline_2025": 38.6,
          "target_2045": 93.5
        }
      ]
    }
  ]
}
```

**Relationships:**
- 5 Sasaran Visi -> masing-masing memiliki indikator baseline 2025 dan target 2045


---

## PDF p.10 (slide 9) — 8 Agenda Transformasi Indonesia

*EN: The 8 Transformation Agendas of Indonesia*  
`type: diagram` `section: transformation_agenda`

**Summary (EN):** The transformation framework toward Indonesia Emas 2045 has eight agendas in three layers: core transformations (1 social, 2 economic, 3 governance); foundations (4 rule of law, stability and diplomatic resilience; 5 socio-cultural and ecological resilience); and the implementation framework (6 equitable regional development, 7 quality green infrastructure, 8 development continuity). These eight agendas correspond to the eight development missions.

**Teks slide (ID):**

```
Kerangka Pikir Transformasi untuk Menuju Indonesia Emas 2045

Transformasi Indonesia
1. Transformasi Sosial
2. Transformasi Ekonomi
3. Transformasi Tata Kelola

Landasan Transformasi
4. Supremasi Hukum, Stabilitas, dan Ketangguhan Diplomasi
5. Ketahanan Sosial Budaya dan Ekologi

Kerangka Implementasi Transformasi
6. Pembangunan Kewilayahan yang Merata dan Berkeadilan
7. Sarana dan Prasarana yang Berkualitas dan Ramah Lingkungan
8. Kesinambungan Pembangunan

Sumber: Rancangan Awal RPJPN 2025-2045
```

**Deskripsi visual (ID):** Tiga blok bertumpuk: 'Transformasi Indonesia' (merah) berisi agenda 1-3, 'Landasan Transformasi' (hijau) berisi agenda 4-5, 'Kerangka Implementasi Transformasi' (biru) berisi agenda 6-8.

**Visual description (EN):** Three stacked blocks: 'Indonesia Transformation' (red) holding agendas 1-3, 'Transformation Foundations' (green) holding agendas 4-5, and 'Transformation Implementation Framework' (blue) holding agendas 6-8.

**Structured data:**

```json
{
  "eight_agendas": [
    {
      "no": 1,
      "group": "Transformasi Indonesia",
      "agenda_id": "Transformasi Sosial",
      "agenda_en": "Social transformation"
    },
    {
      "no": 2,
      "group": "Transformasi Indonesia",
      "agenda_id": "Transformasi Ekonomi",
      "agenda_en": "Economic transformation"
    },
    {
      "no": 3,
      "group": "Transformasi Indonesia",
      "agenda_id": "Transformasi Tata Kelola",
      "agenda_en": "Governance transformation"
    },
    {
      "no": 4,
      "group": "Landasan Transformasi",
      "agenda_id": "Supremasi Hukum, Stabilitas, dan Ketangguhan Diplomasi",
      "agenda_en": "Rule of law, stability and diplomatic resilience"
    },
    {
      "no": 5,
      "group": "Landasan Transformasi",
      "agenda_id": "Ketahanan Sosial Budaya dan Ekologi",
      "agenda_en": "Socio-cultural and ecological resilience"
    },
    {
      "no": 6,
      "group": "Kerangka Implementasi Transformasi",
      "agenda_id": "Pembangunan Kewilayahan yang Merata dan Berkeadilan",
      "agenda_en": "Equitable and just regional development"
    },
    {
      "no": 7,
      "group": "Kerangka Implementasi Transformasi",
      "agenda_id": "Sarana dan Prasarana yang Berkualitas dan Ramah Lingkungan",
      "agenda_en": "High-quality, environmentally friendly infrastructure"
    },
    {
      "no": 8,
      "group": "Kerangka Implementasi Transformasi",
      "agenda_id": "Kesinambungan Pembangunan",
      "agenda_en": "Development continuity"
    }
  ]
}
```

**Relationships:**
- 8 Agenda = 3 Transformasi + 2 Landasan + 3 Kerangka Implementasi
- 8 Agenda Transformasi berkorespondensi dengan 8 Misi Pembangunan


---

## PDF p.11 (slide 10) — 17 Arah Pembangunan

*EN: The 17 Development Directions*  
`type: diagram` `section: transformation_agenda`

**Summary (EN):** Lists the 17 development directions (coded IE1-IE17) of Indonesia Emas 2045, presented as Indonesia's commitment to continuing the 17 SDGs, grouped under the first five missions: Mission 1 Social Transformation (IE1 health for all, IE2 equitable quality education, IE3 adaptive social protection); Mission 2 Economic Transformation (IE4 science/innovation/productivity, IE5 green economy, IE6 digital transformation, IE7 domestic-global economic integration, IE8 cities as growth centres); Mission 3 Governance Transformation (IE9 adaptive regulation and agile, collaborative governance with integrity); Mission 4 Rule of Law, Stability and Diplomacy (IE10 just law, deterrence, security and democracy; IE11 macroeconomic stability; IE12 diplomatic resilience); Mission 5 Socio-cultural and Ecological Resilience (IE13 beneficial religiosity and advanced culture, IE14 quality families and gender equality, IE15 quality environment, IE16 energy, water and food resilience, IE17 disaster and climate resilience). Missions 6-8 (equitable regional development, green infrastructure, development continuity) form the implementation framework.

**Teks slide (ID):**

```
17 Arah (Tujuan) Indonesia Emas Merupakan Komitmen Indonesia dalam Melanjutkan 17 Goals SDGs

TRANSFORMASI INDONESIA
Misi 1. Transformasi Sosial
- IE1 Kesehatan untuk Semua
- IE2 Pendidikan Berkualitas yang Merata
- IE3 Perlindungan Sosial yang Adaptif
Misi 2. Transformasi Ekonomi
- IE4 Iptek, Inovasi, dan Produktivitas Ekonomi
- IE5 Penerapan Ekonomi Hijau
- IE6 Transformasi Digital
- IE7 Integrasi Ekonomi Domestik dan Global
- IE8 Perkotaan sebagai Pusat Pertumbuhan Ekonomi
Misi 3. Transformasi Tata Kelola
- IE9 Regulasi yang Adaptif dan Taat Asas serta Tata Kelola yang Berintegritas, Tangkas dan Kolaboratif

LANDASAN TRANSFORMASI
Misi 4. Supremasi Hukum, Stabilitas, dan Ketangguhan Diplomasi
- IE10 Hukum Berkeadilan, Ketahanan Berdaya Gentar Kawasan, Keamanan Nasional Tangguh, dan Demokrasi Substansial
- IE11 Stabilitas Ekonomi Makro
- IE12 Ketangguhan Diplomasi
Misi 5. Ketahanan Sosial Budaya dan Ekologi
- IE13 Beragama Maslahat dan Berkebudayaan Maju
- IE14 Keluarga Berkualitas dan Kesetaraan Gender
- IE15 Lingkungan Hidup Berkualitas
- IE16 Berketahanan Energi, Air, dan Kemandirian Pangan
- IE17 Resiliensi terhadap Bencana dan Perubahan Iklim

KERANGKA IMPLEMENTASI TRANSFORMASI
Misi 6. Mewujudkan Pembangunan Kewilayahan yang Merata dan Berkeadilan
Misi 7. Mewujudkan Sarana dan Prasarana yang Berkualitas dan Ramah Lingkungan
Misi 8. Mewujudkan Kesinambungan Pembangunan

Sumber: Rancangan Awal RPJPN 2025-2045
```

**Deskripsi visual (ID):** Diagram berbentuk rumah/piramida: tiga pita biru tua (Transformasi Indonesia, Landasan Transformasi, Kerangka Implementasi Transformasi). Di bawah dua pita pertama, 17 arah pembangunan berkode IE1-IE17 dikelompokkan menurut Misi 1-5. Misi 6-8 ditampilkan sebagai tiga baris di bagian paling bawah tanpa kode IE.

**Visual description (EN):** House/pyramid-shaped diagram with three dark-blue bands (Indonesia Transformation, Transformation Foundations, Implementation Framework). Under the first two bands, the 17 development directions coded IE1-IE17 are grouped by Missions 1-5. Missions 6-8 appear as three rows at the bottom without IE codes.

**Structured data:**

```json
{
  "seventeen_directions": [
    {
      "code": "IE1",
      "mission": 1,
      "mission_name": "Transformasi Sosial",
      "direction_id": "Kesehatan untuk Semua",
      "direction_en": "Health for all"
    },
    {
      "code": "IE2",
      "mission": 1,
      "mission_name": "Transformasi Sosial",
      "direction_id": "Pendidikan Berkualitas yang Merata",
      "direction_en": "Equitable quality education"
    },
    {
      "code": "IE3",
      "mission": 1,
      "mission_name": "Transformasi Sosial",
      "direction_id": "Perlindungan Sosial yang Adaptif",
      "direction_en": "Adaptive social protection"
    },
    {
      "code": "IE4",
      "mission": 2,
      "mission_name": "Transformasi Ekonomi",
      "direction_id": "Iptek, Inovasi, dan Produktivitas Ekonomi",
      "direction_en": "Science, technology, innovation and economic productivity"
    },
    {
      "code": "IE5",
      "mission": 2,
      "mission_name": "Transformasi Ekonomi",
      "direction_id": "Penerapan Ekonomi Hijau",
      "direction_en": "Green economy implementation"
    },
    {
      "code": "IE6",
      "mission": 2,
      "mission_name": "Transformasi Ekonomi",
      "direction_id": "Transformasi Digital",
      "direction_en": "Digital transformation"
    },
    {
      "code": "IE7",
      "mission": 2,
      "mission_name": "Transformasi Ekonomi",
      "direction_id": "Integrasi Ekonomi Domestik dan Global",
      "direction_en": "Domestic and global economic integration"
    },
    {
      "code": "IE8",
      "mission": 2,
      "mission_name": "Transformasi Ekonomi",
      "direction_id": "Perkotaan sebagai Pusat Pertumbuhan Ekonomi",
      "direction_en": "Cities as centres of economic growth"
    },
    {
      "code": "IE9",
      "mission": 3,
      "mission_name": "Transformasi Tata Kelola",
      "direction_id": "Regulasi yang Adaptif dan Taat Asas serta Tata Kelola yang Berintegritas, Tangkas dan Kolaboratif",
      "direction_en": "Adaptive, principled regulation and governance with integrity, agility and collaboration"
    },
    {
      "code": "IE10",
      "mission": 4,
      "mission_name": "Supremasi Hukum, Stabilitas, dan Ketangguhan Diplomasi",
      "direction_id": "Hukum Berkeadilan, Ketahanan Berdaya Gentar Kawasan, Keamanan Nasional Tangguh, dan Demokrasi Substansial",
      "direction_en": "Just law, regional deterrence, resilient national security and substantive democracy"
    },
    {
      "code": "IE11",
      "mission": 4,
      "mission_name": "Supremasi Hukum, Stabilitas, dan Ketangguhan Diplomasi",
      "direction_id": "Stabilitas Ekonomi Makro",
      "direction_en": "Macroeconomic stability"
    },
    {
      "code": "IE12",
      "mission": 4,
      "mission_name": "Supremasi Hukum, Stabilitas, dan Ketangguhan Diplomasi",
      "direction_id": "Ketangguhan Diplomasi",
      "direction_en": "Diplomatic resilience"
    },
    {
      "code": "IE13",
      "mission": 5,
      "mission_name": "Ketahanan Sosial Budaya dan Ekologi",
      "direction_id": "Beragama Maslahat dan Berkebudayaan Maju",
      "direction_en": "Beneficial religiosity and advanced culture"
    },
    {
      "code": "IE14",
      "mission": 5,
      "mission_name": "Ketahanan Sosial Budaya dan Ekologi",
      "direction_id": "Keluarga Berkualitas dan Kesetaraan Gender",
      "direction_en": "Quality families and gender equality"
    },
    {
      "code": "IE15",
      "mission": 5,
      "mission_name": "Ketahanan Sosial Budaya dan Ekologi",
      "direction_id": "Lingkungan Hidup Berkualitas",
      "direction_en": "Quality environment"
    },
    {
      "code": "IE16",
      "mission": 5,
      "mission_name": "Ketahanan Sosial Budaya dan Ekologi",
      "direction_id": "Berketahanan Energi, Air, dan Kemandirian Pangan",
      "direction_en": "Energy and water resilience and food self-sufficiency"
    },
    {
      "code": "IE17",
      "mission": 5,
      "mission_name": "Ketahanan Sosial Budaya dan Ekologi",
      "direction_id": "Resiliensi terhadap Bencana dan Perubahan Iklim",
      "direction_en": "Resilience to disasters and climate change"
    }
  ],
  "missions_6_to_8": [
    {
      "mission": 6,
      "name_id": "Mewujudkan Pembangunan Kewilayahan yang Merata dan Berkeadilan"
    },
    {
      "mission": 7,
      "name_id": "Mewujudkan Sarana dan Prasarana yang Berkualitas dan Ramah Lingkungan"
    },
    {
      "mission": 8,
      "name_id": "Mewujudkan Kesinambungan Pembangunan"
    }
  ]
}
```

**Relationships:**
- 17 Arah Pembangunan Indonesia Emas -> kelanjutan 17 Goals SDGs
- Misi 1 Transformasi Sosial -> IE1, IE2, IE3
- Misi 2 Transformasi Ekonomi -> IE4, IE5, IE6, IE7, IE8
- Misi 3 Transformasi Tata Kelola -> IE9
- Misi 4 Supremasi Hukum, Stabilitas, Ketangguhan Diplomasi -> IE10, IE11, IE12
- Misi 5 Ketahanan Sosial Budaya dan Ekologi -> IE13, IE14, IE15, IE16, IE17
- Misi 6, 7, 8 -> Kerangka Implementasi Transformasi (tanpa kode IE)


---

## PDF p.12 (slide 11) — Transformasi Sosial akan Menciptakan Manusia Indonesia Unggul

*EN: Social Transformation Will Create Excellent Indonesian People*  
`type: infographic` `section: social_transformation`

**Summary (EN):** Social transformation aims to produce 'excellent Indonesian people' by 2045. Current conditions (2022): maternal mortality 189 per 100,000 live births, stunting 21.6%, second-highest tuberculosis burden and third-highest leprosy burden in the world, unequal access to quality education, slowing poverty reduction and fragmented social protection. 2045 targets: healthy (stunting below 5%, TB and leprosy eliminated, life expectancy 80 years); smart and educated (mean years of schooling 12.00, higher PISA scores, 67.88% of secondary/tertiary graduates working in medium-high skill jobs); protected and prosperous (adaptive social protection toward 0% poverty).

**Teks slide (ID):**

```
Indonesia saat ini (2022):
Status Kesehatan Rendah
- Angka Kematian Ibu (AKI) masih tinggi (189/100.000 kelahiran hidup)
- Stunting masih tinggi (21,6%)
- Tuberkulosis peringkat ke-2 dunia
- Kusta peringkat ke-3 dunia
Kesenjangan Partisipasi Pendidikan yang Berkualitas
Penurunan Kemiskinan Melambat dan Perlindungan Sosial Terfragmentasi

Indonesia pada tahun 2045: Manusia Indonesia yang Unggul
Sehat
- Sistem kesehatan yang tangguh dan responsif
- Setiap penduduk berusia panjang dan hidup sehat:
  - Stunting dibawah 5%, serta TBC dan Kusta tuntas
  - Usia Harapan Hidup (UHH) menjadi 80 tahun
Cerdas dan Terpelajar
- Pendidikan berkualitas dan merata yang menghasilkan SDM unggul dan berdaya saing
- Rata-rata Lama Sekolah (RLS) menjadi 12,00 tahun
- Skor PISA meningkat
- Persentase pekerja lulusan pendidikan menengah dan tinggi yang bekerja di bidang keahlian menengah tinggi sebesar 67,88%
Terlindungi dan Sejahtera
- Melalui perlindungan sosial yang adaptif menuju kemiskinan 0%
```

**Deskripsi visual (ID):** Kiri: peta Indonesia merah bertitik dengan kondisi saat ini (2022) berikon kesehatan, pendidikan, kemiskinan. Panah emas naik ke kanan menuju 'Indonesia pada tahun 2045 - Manusia Indonesia yang Unggul' dengan tiga kelompok hasil: Sehat, Cerdas dan Terpelajar, Terlindungi dan Sejahtera.

**Visual description (EN):** Left: a red dotted map of Indonesia with current conditions (2022) under health, education and poverty icons. A golden arrow rises to the right toward 'Indonesia in 2045 - Excellent Indonesian People' with three outcome groups: Healthy, Smart and Educated, Protected and Prosperous.

**Structured data:**

```json
{
  "social_transformation": {
    "current_2022": [
      {
        "indicator": "Angka Kematian Ibu (AKI)",
        "value": 189,
        "unit": "per 100,000 live births"
      },
      {
        "indicator": "Stunting",
        "value": 21.6,
        "unit": "%"
      },
      {
        "indicator": "Tuberkulosis",
        "value": "2nd highest burden in the world"
      },
      {
        "indicator": "Kusta (leprosy)",
        "value": "3rd highest in the world"
      },
      {
        "indicator": "Kesenjangan partisipasi pendidikan berkualitas",
        "value": null
      },
      {
        "indicator": "Penurunan kemiskinan melambat; perlindungan sosial terfragmentasi",
        "value": null
      }
    ],
    "targets_2045": [
      {
        "pillar": "Sehat",
        "indicator": "Stunting",
        "value": "< 5",
        "unit": "%"
      },
      {
        "pillar": "Sehat",
        "indicator": "TBC dan Kusta",
        "value": "tuntas (eliminated)"
      },
      {
        "pillar": "Sehat",
        "indicator": "Usia Harapan Hidup (UHH)",
        "value": 80,
        "unit": "years"
      },
      {
        "pillar": "Cerdas dan Terpelajar",
        "indicator": "Rata-rata Lama Sekolah (RLS)",
        "value": 12.0,
        "unit": "years"
      },
      {
        "pillar": "Cerdas dan Terpelajar",
        "indicator": "Skor PISA",
        "value": "meningkat (increase)"
      },
      {
        "pillar": "Cerdas dan Terpelajar",
        "indicator": "Pekerja lulusan menengah/tinggi di keahlian menengah-tinggi",
        "value": 67.88,
        "unit": "%"
      },
      {
        "pillar": "Terlindungi dan Sejahtera",
        "indicator": "Kemiskinan",
        "value": 0,
        "unit": "%"
      }
    ]
  }
}
```

**Relationships:**
- Transformasi Sosial -> Manusia Indonesia Unggul (Sehat, Cerdas dan Terpelajar, Terlindungi dan Sejahtera)
- Kondisi 2022 (AKI tinggi, stunting 21.6%) -> target 2045 (stunting <5%, UHH 80)


---

## PDF p.13 (slide 12) — Transformasi Ekonomi akan Membawa Indonesia Keluar dari Middle Income Trap

*EN: Economic Transformation Will Take Indonesia Out of the Middle Income Trap*  
`type: chart` `section: economic_transformation`

**Summary (EN):** Economic transformation is meant to lift Indonesia out of the middle-income trap, where it has been for 30 years (1993-2022). Two scenarios: transformative growth averaging 6% exits the trap in 2041; a very optimistic 7% exits in 2038. With 7% average growth, Indonesia in 2045 would have nominal GDP of USD 9.8 trillion (5th largest in the world), GNI per capita of USD 30,300, an 80% middle-income class, average investment growth of 6.8%, an ICOR of 4.6, and manufacturing contributing 28% of GDP and 25.2% of employment, driven by productivity-led growth.

**Teks slide (ID):**

```
Proyeksi GNI per Kapita Indonesia (USD)
Indonesia sudah terjebak dalam MIT selama 30 tahun (1993-2022)
22 TAHUN
Proyeksi High Income Threshold
Upper-Middle Income Threshold
Productivity-Led Growth

Skenario | Rata-rata Pertumbuhan | Tahun keluar MIT
Transformatif | 6% | 2041
Sangat Optimis | 7% | 2038

Indonesia pada tahun 2045 ... dengan pertumbuhan rata-rata 7%...
- PDB Nominal: USD 9,8 T
- PDB: 5 Besar Dunia
- GNI per Kapita: USD 30.300
- Middle Income Class: 80%
- Rata-Rata Pertumbuhan Investasi: 6,8%
- ICOR: 4,6 Pada tahun 2045
- Industri Manufaktur: Kontribusi PDB: 28%; Kontribusi tenaga kerja: 25,2%
```

**Deskripsi visual (ID):** Grafik garis proyeksi GNI per kapita Indonesia 1969-2044 (USD, sumbu 0-35.000): garis hitam historis, garis merah skenario 6% dan garis kuning skenario 7%, garis putus-putus biru ambang high income dan merah ambang upper-middle income. Penanda vertikal pada 2038 (kuning) dan 2041 (merah) menunjukkan tahun keluar MIT. Catatan: Indonesia terjebak MIT 30 tahun (1993-2022); panah '22 tahun' menandai sisa waktu. Tabel skenario di bawah grafik. Kanan: panel KPI 2045 (PDB nominal, peringkat PDB, GNI per kapita, kelas menengah, investasi, ICOR, manufaktur).

**Visual description (EN):** Line chart projecting Indonesia's GNI per capita 1969-2044 (USD, axis 0-35,000): black historical line, red 6% scenario and yellow 7% scenario, with dashed blue high-income threshold and dashed red upper-middle-income threshold. Vertical markers at 2038 (yellow) and 2041 (red) show the year of exiting the middle-income trap. Note that Indonesia has been in the MIT for 30 years (1993-2022); a '22 years' arrow marks the remaining window. Scenario table below the chart. Right: 2045 KPI panel (nominal GDP, GDP rank, GNI per capita, middle class, investment growth, ICOR, manufacturing).

**Structured data:**

```json
{
  "mit_scenarios": [
    {
      "scenario_id": "Transformatif",
      "scenario_en": "Transformative",
      "avg_growth_pct": 6,
      "exit_mit_year": 2041
    },
    {
      "scenario_id": "Sangat Optimis",
      "scenario_en": "Very optimistic",
      "avg_growth_pct": 7,
      "exit_mit_year": 2038
    }
  ],
  "mit_history": {
    "years_in_mit": 30,
    "period": "1993-2022"
  },
  "indonesia_2045_economy": {
    "assumed_avg_growth_pct": 7,
    "nominal_gdp_usd_trillion": 9.8,
    "gdp_world_rank": 5,
    "gni_per_capita_usd": 30300,
    "middle_income_class_pct": 80,
    "avg_investment_growth_pct": 6.8,
    "icor_2045": 4.6,
    "manufacturing_gdp_share_pct": 28,
    "manufacturing_employment_share_pct": 25.2
  }
}
```

**Relationships:**
- Pertumbuhan rata-rata 6% -> keluar MIT 2041
- Pertumbuhan rata-rata 7% -> keluar MIT 2038
- Transformasi ekonomi (productivity-led growth) -> keluar MIT -> ekonomi 2045 (PDB USD 9.8 T, 5 besar dunia)


---

## PDF p.14 (slide 13) — Transformasi Tata Kelola akan Menciptakan Pelayanan Publik Berkualitas dan Masyarakat Sipil Partisipatif

*EN: Governance Transformation Will Create Quality Public Services and a Participatory Civil Society*  
`type: infographic` `section: governance_transformation`

**Summary (EN):** Governance transformation addresses today's inefficient regulation and bureaucracy, persistent corruption, sub-par public services and limited civil-society participation. By 2045 the aim is institutions and bureaucracy with integrity, agility and collaboration (quality adaptive regulation, collaborative-governance performance management, a single salary system and pension reform, movement toward zero corruption); quality, easy, fast and guaranteed public services (digital delivery, strong oversight); and an independent, participatory civil society with meaningful participation and political parties of integrity.

**Teks slide (ID):**

```
Indonesia saat ini:
- Inefisiensi regulasi dan birokrasi.
- Perilaku koruptif yang masih tinggi.
- Pelayanan publik belum prima.
- Partisipasi masyarakat sipil dalam pembangunan dan demokratisasi belum optimal.

Indonesia pada tahun 2045
KELEMBAGAAN DAN BIROKRASI YANG BERINTEGRITAS, TANGKAS, DAN KOLABORATIF:
- Regulasi berkualitas dan adaptif
- Pengelolaan kinerja berbasis collaborative governance.
- Sistem penggajian tunggal (single salary system) dan reformasi sistem pensiun.
- Menuju Zero Corruption.
PELAYANAN PUBLIK YANG BERKUALITAS, MUDAH, CEPAT, DAN TERJAMIN:
- Pelayanan publik secara digital.
- Sistem pengawasan dan pelayanan publik berkualitas.
MASYARAKAT SIPIL MANDIRI DAN PARTISIPATIF
- Partisipasi masyarakat sipil yang bermakna terhadap pembangunan.
- Partai politik yang berintegritas.
```

**Deskripsi visual (ID):** Kiri: peta Indonesia merah bertitik dan daftar kondisi tata kelola saat ini. Panah emas naik ke kanan menuju 'Indonesia pada tahun 2045' dengan tiga kelompok hasil berikon: kelembagaan/birokrasi, pelayanan publik, masyarakat sipil.

**Visual description (EN):** Left: red dotted map of Indonesia with current governance problems. A golden arrow rises to 'Indonesia in 2045' with three icon-led outcome groups: institutions/bureaucracy, public services, civil society.

**Structured data:**

```json
{
  "governance_transformation": {
    "current_problems": [
      "Inefisiensi regulasi dan birokrasi",
      "Perilaku koruptif yang masih tinggi",
      "Pelayanan publik belum prima",
      "Partisipasi masyarakat sipil belum optimal"
    ],
    "targets_2045": {
      "kelembagaan_birokrasi": [
        "Regulasi berkualitas dan adaptif",
        "Pengelolaan kinerja berbasis collaborative governance",
        "Single salary system dan reformasi sistem pensiun",
        "Menuju Zero Corruption"
      ],
      "pelayanan_publik": [
        "Pelayanan publik secara digital",
        "Sistem pengawasan dan pelayanan publik berkualitas"
      ],
      "masyarakat_sipil": [
        "Partisipasi masyarakat sipil yang bermakna",
        "Partai politik yang berintegritas"
      ]
    }
  }
}
```

**Relationships:**
- Transformasi Tata Kelola -> kelembagaan berintegritas/tangkas/kolaboratif + pelayanan publik berkualitas + masyarakat sipil mandiri partisipatif


---

## PDF p.15 (slide 14) — Tahapan Pembangunan 2025-2045

*EN: Development Phases 2025-2045*  
`type: diagram` `section: development_phases`

**Summary (EN):** The RPJPN 2025-2045 unfolds in four five-year phases, each with social, economic and governance focuses: Phase 1 (2025-2029) strengthening the foundation - basic health, education and social protection; natural-resource downstreaming plus research, innovation and labour productivity; fit-for-purpose institutions, regulatory reform, merit-based civil service, evidence-based policy, IT-based services. Phase 2 (2030-2034) acceleration - inclusive quality human capital; massive productivity gains and new growth sources; collaborative institutions, competent civil servants, IT-based regulatory simplification, political parties with integrity. Phase 3 (2035-2039) global expansion - competitive human resources; an economic powerhouse integrated into global and domestic value chains with robust exports; adaptive institutions, a single regulatory body, independent civil society. Phase 4 (2040-2045) realising Golden Indonesia - excellent people, a high-income country, adaptive regulation and governance with integrity, agility and collaboration.

**Teks slide (ID):**

```
Tahap 1: Perkuatan Fondasi Transformasi (2025-2029)
- Transformasi Sosial: Pemenuhan pelayanan dasar kesehatan, pendidikan, dan perlindungan sosial
- Transformasi Ekonomi: Hilirisasi SDA serta penguatan riset inovasi dan produktivitas tenaga kerja
- Transformasi Tata Kelola: Kelembagaan tepat fungsi, penyempurnaan fondasi penataan regulasi, kualitas ASN berbasis merit, kebijakan pembangunan berbasis bukti, penerapan manajemen risiko, pelayanan publik berbasis TI, serta penguatan kapasitas masyarakat sipil

Tahap 2: Akselerasi Transformasi (2030-2034)
- Transformasi Sosial: Percepatan pembangunan SDM berkualitas dan inklusif
- Transformasi Ekonomi: Peningkatan produktivitas secara masif serta perluasan sumber pertumbuhan ekonomi
- Transformasi Tata Kelola: Kelembagaan kolaboratif, SDM ASN sejahtera, proporsional, dan berkompeten, simplifikasi regulasi berbasis TI, partai politik yang berintegritas, serta masyarakat sipil yang partisipatif

Tahap 3: Ekspansi Global (2035-2039)
- Transformasi Sosial: Penguatan daya saing SDM dan keberlanjutan kesejahteraan
- Transformasi Ekonomi: Economic power house yang terintegrasi dengan jaringan rantai nilai global dan domestik, serta ekspor yang kokoh
- Transformasi Tata Kelola: Kelembagaan adaptif, SDM ASN kompetitif, partai politik yang transparan dan akuntabel, lembaga tunggal regulasi, serta masyarakat sipil mandiri

Tahap 4: Perwujudan Indonesia Emas (2040-2045)
- Transformasi Sosial: Manusia Indonesia yang unggul
- Transformasi Ekonomi: Negara berpendapatan tinggi
- Transformasi Tata Kelola: Regulasi yang adaptif dan taat asas serta tata kelola yang berintegritas, tangkas, dan kolaboratif
```

**Deskripsi visual (ID):** Empat kolom heksagon berikon (fondasi, roket, jaringan global, peta Indonesia Emas 2045) untuk Tahap 1-4 dengan rentang tahun; tiga baris horizontal (Transformasi Sosial, Ekonomi, Tata Kelola) mengisi matriks 3x4.

**Visual description (EN):** Four hexagon columns with icons (foundation piles, rocket, global network, Indonesia Emas 2045 map) for Phases 1-4 with year ranges; three horizontal rows (Social, Economic, Governance transformation) fill a 3x4 matrix.

**Structured data:**

```json
{
  "phases": [
    {
      "phase": 1,
      "name_id": "Perkuatan Fondasi Transformasi",
      "name_en": "Strengthening the transformation foundation",
      "period": "2025-2029",
      "sosial": "Pemenuhan pelayanan dasar kesehatan, pendidikan, dan perlindungan sosial",
      "ekonomi": "Hilirisasi SDA serta penguatan riset inovasi dan produktivitas tenaga kerja",
      "tata_kelola": "Kelembagaan tepat fungsi, penyempurnaan fondasi penataan regulasi, kualitas ASN berbasis merit, kebijakan pembangunan berbasis bukti, penerapan manajemen risiko, pelayanan publik berbasis TI, serta penguatan kapasitas masyarakat sipil"
    },
    {
      "phase": 2,
      "name_id": "Akselerasi Transformasi",
      "name_en": "Accelerating transformation",
      "period": "2030-2034",
      "sosial": "Percepatan pembangunan SDM berkualitas dan inklusif",
      "ekonomi": "Peningkatan produktivitas secara masif serta perluasan sumber pertumbuhan ekonomi",
      "tata_kelola": "Kelembagaan kolaboratif, SDM ASN sejahtera, proporsional, dan berkompeten, simplifikasi regulasi berbasis TI, partai politik yang berintegritas, serta masyarakat sipil yang partisipatif"
    },
    {
      "phase": 3,
      "name_id": "Ekspansi Global",
      "name_en": "Global expansion",
      "period": "2035-2039",
      "sosial": "Penguatan daya saing SDM dan keberlanjutan kesejahteraan",
      "ekonomi": "Economic power house yang terintegrasi dengan jaringan rantai nilai global dan domestik, serta ekspor yang kokoh",
      "tata_kelola": "Kelembagaan adaptif, SDM ASN kompetitif, partai politik yang transparan dan akuntabel, lembaga tunggal regulasi, serta masyarakat sipil mandiri"
    },
    {
      "phase": 4,
      "name_id": "Perwujudan Indonesia Emas",
      "name_en": "Realising Golden Indonesia",
      "period": "2040-2045",
      "sosial": "Manusia Indonesia yang unggul",
      "ekonomi": "Negara berpendapatan tinggi",
      "tata_kelola": "Regulasi yang adaptif dan taat asas serta tata kelola yang berintegritas, tangkas, dan kolaboratif"
    }
  ]
}
```

**Relationships:**
- RPJPN 2025-2045 -> 4 tahap lima-tahunan
- Setiap tahap -> fokus Transformasi Sosial, Ekonomi, Tata Kelola
- Tahap 1-4 berkorespondensi dengan RPJMN 1-4


---

## PDF p.16 (slide 15) — Indonesia dihadapi Isu Ketimpangan antar Wilayah...

*EN: Indonesia Faces the Issue of Inter-Regional Inequality*  
`type: chart` `section: regional_inequality`

**Summary (EN):** Illustrates inter-regional inequality with 2022 GRDP per capita (USD, current prices) by province: DKI Jakarta (20,103) and East Kalimantan (16,083) are high income; the national average is 4,786; and 20 provinces are lower-middle income, from Banten (4,109) down to East Nusa Tenggara (1,463), with Maluku (1,923) and West Nusa Tenggara (1,932) also near the bottom. The policy message is that higher economic growth must be prioritised in lower-middle-income regions.

**Teks slide (ID):**

```
PDRB Per Kapita 2022 (USD per Kapita)
[Grafik batang 34 provinsi + Indonesia, dikelompokkan High Income / Upper-Middle Income / Lower-Middle Income]

Sebagai contoh...... 20 Provinsi Berada dalam Kategori Lower-Middle Income

Pertumbuhan ekonomi yang Lebih tinggi perlu diprioritaskan di wilayah yang berstatus Lower-Middle Income

*PDRB per Kapita Atas Dasar Harga Berlaku
```

**Deskripsi visual (ID):** Grafik batang horizontal PDRB per kapita 2022 (USD) untuk 34 provinsi dan rata-rata Indonesia, diurutkan menurun; warna hijau tua = High Income (DKI Jakarta, Kalimantan Timur), hijau muda = Upper-Middle Income, kuning = Lower-Middle Income (20 provinsi dalam kotak putus-putus merah). Peta Indonesia di kanan mewarnai provinsi menurut kategori yang sama.

**Visual description (EN):** Horizontal bar chart of 2022 GRDP per capita (USD) for 34 provinces plus the Indonesia average, sorted descending; dark green = High Income (DKI Jakarta, East Kalimantan), light green = Upper-Middle Income, yellow = Lower-Middle Income (20 provinces inside a red dashed box). A map of Indonesia on the right colours provinces by the same categories.

**Structured data:**

```json
{
  "grdp_per_capita_2022_usd": {
    "note": "PDRB per kapita atas dasar harga berlaku (current prices)",
    "rows": [
      [
        "DKI Jakarta",
        20103,
        "High Income"
      ],
      [
        "Kalimantan Timur",
        16083,
        "High Income"
      ],
      [
        "Kalimantan Utara",
        12843,
        "Upper-Middle Income"
      ],
      [
        "Riau",
        10101,
        "Upper-Middle Income"
      ],
      [
        "Kep. Riau",
        9546,
        "Upper-Middle Income"
      ],
      [
        "Sulawesi Tengah",
        7112,
        "Upper-Middle Income"
      ],
      [
        "Papua Barat",
        5198,
        "Upper-Middle Income"
      ],
      [
        "Jambi",
        5127,
        "Upper-Middle Income"
      ],
      [
        "Kalimantan Tengah",
        4915,
        "Upper-Middle Income"
      ],
      [
        "INDONESIA",
        4786,
        "Upper-Middle Income"
      ],
      [
        "Sumatera Selatan",
        4605,
        "Upper-Middle Income"
      ],
      [
        "Jawa Timur",
        4472,
        "Upper-Middle Income"
      ],
      [
        "Sulawesi Selatan",
        4420,
        "Upper-Middle Income"
      ],
      [
        "Kep. Bangka Belitung",
        4296,
        "Upper-Middle Income"
      ],
      [
        "Sumatera Utara",
        4258,
        "Upper-Middle Income"
      ],
      [
        "Banten",
        4109,
        "Lower-Middle Income"
      ],
      [
        "Kalimantan Selatan",
        4048,
        "Lower-Middle Income"
      ],
      [
        "Papua",
        4003,
        "Lower-Middle Income"
      ],
      [
        "Sulawesi Utara",
        3978,
        "Lower-Middle Income"
      ],
      [
        "Sulawesi Tenggara",
        3959,
        "Lower-Middle Income"
      ],
      [
        "Bali",
        3743,
        "Lower-Middle Income"
      ],
      [
        "Maluku Utara",
        3621,
        "Lower-Middle Income"
      ],
      [
        "Sumatera Barat",
        3409,
        "Lower-Middle Income"
      ],
      [
        "Jawa Barat",
        3304,
        "Lower-Middle Income"
      ],
      [
        "Kalimantan Barat",
        3110,
        "Lower-Middle Income"
      ],
      [
        "Lampung",
        3041,
        "Lower-Middle Income"
      ],
      [
        "DI Yogyakarta",
        2968,
        "Lower-Middle Income"
      ],
      [
        "Bengkulu",
        2947,
        "Lower-Middle Income"
      ],
      [
        "Jawa Tengah",
        2840,
        "Lower-Middle Income"
      ],
      [
        "Gorontalo",
        2688,
        "Lower-Middle Income"
      ],
      [
        "Aceh",
        2638,
        "Lower-Middle Income"
      ],
      [
        "Sulawesi Barat",
        2498,
        "Lower-Middle Income"
      ],
      [
        "Nusa Tenggara Barat",
        1932,
        "Lower-Middle Income"
      ],
      [
        "Maluku",
        1923,
        "Lower-Middle Income"
      ],
      [
        "Nusa Tenggara Timur",
        1463,
        "Lower-Middle Income"
      ]
    ],
    "columns": [
      "province",
      "grdp_per_capita_usd_2022",
      "income_category"
    ],
    "lower_middle_income_province_count": 20
  }
}
```

**Relationships:**
- 20 provinsi berstatus Lower-Middle Income -> perlu diprioritaskan pertumbuhan ekonomi lebih tinggi


---

## PDF p.17 (slide 16) — Setiap Daerah Memiliki Isu Prioritas Pembangunan yang Berbeda-Beda

*EN: Each Region Has Different Priority Development Issues*  
`type: map` `section: regional_priorities`

**Summary (EN):** Growth-diagnostics results (Bappenas Economic Deputy, 2022 update) show that each province in Java and Bali has a different binding constraint: DKI Jakarta - financing (consumer and services credit); Banten and West Java - health human capital (birth rate, BPJS PBI subsidised insurance coverage, morbidity, hospitals and health workers, unmet health needs); Central Java - education (mean years of schooling, net enrolment in primary and senior secondary); Yogyakarta - macro-fiscal (inflation, fiscal independence, openness to foreign investors); East Java - labour (open unemployment, secondary/tertiary-educated workforce, agricultural and manufacturing productivity, share of formal employment); Bali - financing (low consumer, working-capital, agriculture and manufacturing credit).

**Teks slide (ID):**

```
HASIL GROWTH DIAGNOSTICS untuk PROVINSI JAWA DAN BALI

DKI JAKARTA
- Kredit Konsumsi dan kredit sektor jasa
BANTEN
- Angka kelahiran
- Asuransi BPJS PBI
- Tingkat kesakitan
- Jumlah RS dan nakes
JAWA BARAT
- Asuransi BPJS PBI
- Unmet need pelayanan kesehatan
- Tingkat kesakitan
- Jumlah RS dan nakes
JAWA TENGAH
- Rata-rata lama sekolah
- Angka Partisipasi Murni (APM) jenjang SD dan SMA
DI YOGYAKARTA
- Inflasi
- Tingkat kemandirian fiskal
- Tingkat keterbukaan, attractiveness to foreign investor
JAWA TIMUR
- Tingkat Pengangguran Terbuka
- Tenaga kerja lulusan pendidikan sekunder dan tersier
- Produktivitas tenaga kerja sektor pertanian dan industri pengolahan
- Proporsi tenaga kerja formal
BALI
- Kredit konsumsi dan modal kerja masih relatif rendah
- Kredit sektor pertanian dan manufaktur masih relatif rendah

Legenda: SDM Ketenagakerjaan (kuning); SDM Kesehatan (abu-abu); SDM Pendidikan (hijau); Infrastruktur (biru muda); Regulasi dan Institusi (merah); Aspek Pembiayaan (oranye); Makro dan Fiskal (biru tua); Daya Saing (ungu)

*) Analisis Kedeputian Bidang Ekonomi (Bappenas) dengan menggunakan basis growth diagnostic, updating tahun 2022 (diolah)
```

**Deskripsi visual (ID):** Peta Pulau Jawa dan Bali; setiap provinsi diwarnai menurut kategori hambatan utama hasil growth diagnostics (DKI Jakarta oranye = pembiayaan; Banten dan Jawa Barat abu-abu = SDM kesehatan; Jawa Tengah hijau = SDM pendidikan; DI Yogyakarta biru tua = makro dan fiskal; Jawa Timur kuning = SDM ketenagakerjaan; Bali oranye = pembiayaan), dengan lambang provinsi dan kotak callout berisi indikator penghambat.

**Visual description (EN):** Map of Java and Bali; each province is coloured by its binding-constraint category from growth diagnostics (DKI Jakarta orange = financing; Banten and West Java grey = health human capital; Central Java green = education human capital; Yogyakarta dark blue = macro and fiscal; East Java yellow = labour/employment; Bali orange = financing), with provincial coats of arms and callout boxes listing the constraining indicators.

**Structured data:**

```json
{
  "growth_diagnostics_java_bali": [
    {
      "province": "DKI Jakarta",
      "constraint_category": "Aspek Pembiayaan",
      "category_en": "Financing",
      "indicators": [
        "Kredit konsumsi dan kredit sektor jasa"
      ]
    },
    {
      "province": "Banten",
      "constraint_category": "SDM Kesehatan",
      "category_en": "Health human capital",
      "indicators": [
        "Angka kelahiran",
        "Asuransi BPJS PBI",
        "Tingkat kesakitan",
        "Jumlah RS dan nakes"
      ]
    },
    {
      "province": "Jawa Barat",
      "constraint_category": "SDM Kesehatan",
      "category_en": "Health human capital",
      "indicators": [
        "Asuransi BPJS PBI",
        "Unmet need pelayanan kesehatan",
        "Tingkat kesakitan",
        "Jumlah RS dan nakes"
      ]
    },
    {
      "province": "Jawa Tengah",
      "constraint_category": "SDM Pendidikan",
      "category_en": "Education human capital",
      "indicators": [
        "Rata-rata lama sekolah",
        "Angka Partisipasi Murni (APM) SD dan SMA"
      ]
    },
    {
      "province": "DI Yogyakarta",
      "constraint_category": "Makro dan Fiskal",
      "category_en": "Macro and fiscal",
      "indicators": [
        "Inflasi",
        "Tingkat kemandirian fiskal",
        "Tingkat keterbukaan / attractiveness to foreign investor"
      ]
    },
    {
      "province": "Jawa Timur",
      "constraint_category": "SDM Ketenagakerjaan",
      "category_en": "Labour / employment",
      "indicators": [
        "Tingkat Pengangguran Terbuka",
        "Tenaga kerja lulusan pendidikan sekunder dan tersier",
        "Produktivitas tenaga kerja pertanian dan industri pengolahan",
        "Proporsi tenaga kerja formal"
      ]
    },
    {
      "province": "Bali",
      "constraint_category": "Aspek Pembiayaan",
      "category_en": "Financing",
      "indicators": [
        "Kredit konsumsi dan modal kerja relatif rendah",
        "Kredit sektor pertanian dan manufaktur relatif rendah"
      ]
    }
  ],
  "constraint_categories": [
    "SDM Ketenagakerjaan",
    "SDM Kesehatan",
    "SDM Pendidikan",
    "Infrastruktur",
    "Regulasi dan Institusi",
    "Aspek Pembiayaan",
    "Makro dan Fiskal",
    "Daya Saing"
  ],
  "method": "Growth diagnostics, Kedeputian Bidang Ekonomi Bappenas, 2022 update"
}
```

**Relationships:**
- Setiap provinsi -> hambatan pertumbuhan utama berbeda (growth diagnostics)
- DKI Jakarta & Bali -> pembiayaan; Banten & Jawa Barat -> SDM kesehatan; Jawa Tengah -> SDM pendidikan; DI Yogyakarta -> makro-fiskal; Jawa Timur -> ketenagakerjaan


---

## PDF p.18 (slide 17) — Setiap Daerah Memiliki Isu Prioritas Pembangunan yang Berbeda-Beda

*EN: Each Region Has Different Priority Development Issues (duplicate of page 17)*  
`type: duplicate` `section: regional_priorities`

Duplicate of bappenas-keynote-2045-p17.

---

## PDF p.19 — Contoh Lain: Hasil Growth Diagnostics Hambatan Utama Pertumbuhan Ekonomi di Wilayah Maluku

*EN: Another Example: Growth Diagnostics Results on the Main Constraints to Economic Growth in the Maluku Region*  
`type: heatmap` `section: regional_priorities`

**Summary (EN):** Growth diagnostics for the Maluku region (Maluku and North Maluku provinces) identify connectivity infrastructure as the main binding constraint. In the colour-coded matrix, infrastructure is red for North Maluku and orange-red for Maluku; Maluku also shows macro-fiscal as a severe (red) constraint, while North Maluku shows financing, education, macro-fiscal and competitiveness as moderate-to-severe (orange). Labour and health are the least constraining factors.

**Teks slide (ID):**

```
FAKTOR PENGHAMBAT UTAMA WILAYAH MALUKU ADALAH INFRASTRUKTUR KONEKTIVITAS

[Matriks: baris Maluku, Maluku Utara; kolom Pembiayaan, SDM: Ketenagakerjaan, SDM: Pendidikan, SDM: Kesehatan, Infrastruktur, Regulasi dan Institusi, Makro dan Fiskal, Daya Saing]
Skala warna: Bukan Faktor Penghambat (hijau) -> Faktor Penghambat Utama (merah)
```

**Deskripsi visual (ID):** Matriks titik berwarna (heatmap) 2 baris x 8 kolom: Maluku dan Maluku Utara terhadap delapan kategori faktor. Warna dari hijau (bukan penghambat) ke merah (penghambat utama). Kolom Infrastruktur diberi kotak putus-putus merah dan panah biru. Maluku: pembiayaan kuning, ketenagakerjaan hijau, pendidikan hijau-kuning, kesehatan hijau-kuning, infrastruktur oranye-merah, regulasi oranye, makro-fiskal merah, daya saing hijau-kuning. Maluku Utara: pembiayaan oranye, ketenagakerjaan kuning, pendidikan oranye, kesehatan kuning, infrastruktur merah, regulasi kuning, makro-fiskal oranye, daya saing oranye.

**Visual description (EN):** Coloured-dot heatmap, 2 rows x 8 columns: Maluku and North Maluku against eight constraint categories. Colour runs from green (not a constraint) to red (main constraint). The Infrastructure column is boxed in red dashes with a blue arrow. Maluku: financing yellow, labour green, education yellow-green, health yellow-green, infrastructure orange-red, regulation orange, macro-fiscal red, competitiveness yellow-green. North Maluku: financing orange, labour yellow, education orange, health yellow, infrastructure red, regulation yellow, macro-fiscal orange, competitiveness orange.

**Structured data:**

```json
{
  "growth_diagnostics_maluku": {
    "scale": {
      "0": "green - bukan faktor penghambat",
      "1": "yellow-green",
      "2": "yellow",
      "3": "orange",
      "4": "red - faktor penghambat utama"
    },
    "columns": [
      "Pembiayaan",
      "SDM Ketenagakerjaan",
      "SDM Pendidikan",
      "SDM Kesehatan",
      "Infrastruktur",
      "Regulasi dan Institusi",
      "Makro dan Fiskal",
      "Daya Saing"
    ],
    "rows": {
      "Maluku": [
        2,
        0,
        1,
        1,
        3.5,
        3,
        4,
        1
      ],
      "Maluku Utara": [
        3,
        2,
        3,
        2,
        4,
        2,
        3,
        3
      ]
    },
    "headline_constraint": "Infrastruktur konektivitas",
    "note": "Severity values are read from dot colours; approximate ordinal scale, not published numbers."
  }
}
```

**Relationships:**
- Wilayah Maluku -> faktor penghambat utama = infrastruktur konektivitas
- Maluku -> makro dan fiskal juga merah (penghambat berat)
- Maluku Utara -> infrastruktur merah; pembiayaan, pendidikan, makro-fiskal, daya saing oranye


---

## PDF p.20 (slide 18) — Sehingga...kebijakan wilayah harus fokus pada faktor penghambat utama Pembangunan...

*EN: Therefore... Regional Policy Must Focus on the Main Constraints to Development*  
`type: text_with_map` `section: regional_priorities`

**Summary (EN):** Example of how regional policy should target the binding constraint, using Maluku: complete the Trans Maluku, Trans Halmahera and outer-island (3T - frontier, outermost, disadvantaged) roads as part of multimodal transport; develop urban mass transit starting in Ambon, Ternate and Sofifi; build grid interconnection, smart grids and renewable-based isolated island grids for stable electricity; and eradicate extreme poverty in 3T areas across Maluku. A thematic Bappenas map shows fishery, plantation, mining, tourism and technopark locations and the ALKI III sea lanes.

**Teks slide (ID):**

```
CONTOH PENYELESAIAN FAKTOR PENGHAMBAT UTAMA PEMBANGUNAN WILAYAH MALUKU
- Penyelesaian jalan Trans Maluku, Trans Halmahera, dan trans pulau-pulau 3T sebagai bagian transportasi multimoda untuk menjangkau seluruh wilayah Maluku
- Pengembangan transportasi perkotaan termasuk sistem angkutan umum massal di kota besar dimulai dari kota Ambon, Ternate, dan Sofifi
- Pengembangan sistem interkoneksi untuk meningkatkan kestabilan keadaan pasokan listrik serta pengembangan smart grid dan sistem terisolasi (Isolated Grid) kepulauan berbasis energi terbarukan
- Pengentasan kemiskinan ekstrem pada daerah 3T di seluruh Wilayah Maluku
```

**Deskripsi visual (ID):** Empat kotak teks berisi contoh intervensi di kiri. Di kanan, peta tematik Provinsi Maluku dan Maluku Utara (disusun Bappenas 2023; sumber: analisis provinsi, RIPPN-KKP, RIPPARNAS-Kemenparekraf) menandai kawasan ekonomi, sentra perikanan tuna/tongkol/rumput laut, perkebunan pala/cengkeh/kelapa, technopark (Maritime Science Technopark, Spices Science Technopark, Coconut Science Technopark, Seaweed Science Technopark), kawasan pariwisata (Morotai, Banda Neira, Kei/Tual, Manusela-Masohi), industri pertambangan (Teluk Weda, Pulau Obi), bandara dan pelabuhan untuk ekspor komoditas unggulan, serta jalur ALKI III B dan ALKI III C. Teks peta terlalu kecil untuk dibaca seluruhnya.

**Visual description (EN):** Four text boxes with example interventions on the left. On the right, a thematic map of Maluku and North Maluku provinces (compiled by Bappenas 2023; sources: provincial analysis, RIPPN-KKP, RIPPARNAS-Kemenparekraf) marking economic zones, tuna/skipjack/seaweed fishery centres, nutmeg/clove/coconut plantation centres, technoparks (Maritime Science, Spices Science, Coconut Science, Seaweed Science), tourism areas (Morotai, Banda Neira, Kei/Tual, Manusela-Masohi), mining industry areas (Weda Bay, Obi Island), airports and ports for export of flagship commodities, and the ALKI III B and III C sea lanes. Map text is too small to read in full.

**Structured data:**

```json
{
  "maluku_interventions": [
    {
      "area": "Konektivitas darat/multimoda",
      "action": "Penyelesaian jalan Trans Maluku, Trans Halmahera, dan trans pulau-pulau 3T"
    },
    {
      "area": "Transportasi perkotaan",
      "action": "Angkutan umum massal di Ambon, Ternate, Sofifi"
    },
    {
      "area": "Energi",
      "action": "Interkoneksi listrik, smart grid, isolated grid kepulauan berbasis energi terbarukan"
    },
    {
      "area": "Kemiskinan",
      "action": "Pengentasan kemiskinan ekstrem di daerah 3T seluruh Wilayah Maluku"
    }
  ],
  "map_features_partial": [
    "Maritime Science Technopark",
    "Spices Science Technopark",
    "Coconut Science Technopark",
    "Seaweed Science Technopark",
    "Kawasan ekonomi Morotai (pariwisata, perikanan)",
    "Teluk Weda industri pertambangan",
    "Pulau Obi industri pertambangan",
    "Banda Neira pariwisata",
    "Kei (Tual) pariwisata",
    "Manusela-Masohi pariwisata",
    "ALKI III B",
    "ALKI III C"
  ]
}
```

**Relationships:**
- Hambatan infrastruktur konektivitas Maluku -> intervensi: jalan trans, angkutan massal, interkoneksi listrik/energi terbarukan, pengentasan kemiskinan ekstrem 3T


---

## PDF p.21 (slide 19) — Oleh sebab itu...Daerah Perlu Mengacu kepada RPJPN untuk Menjaga Konsistensi Perencanaan Pusat dan Daerah

*EN: Therefore... Regions Need to Refer to the RPJPN to Maintain Consistency between Central and Regional Planning*  
`type: diagram` `section: central_regional_alignment`

**Summary (EN):** Explains the cascade of Indonesian planning documents that keeps central and regional planning consistent: the national long-term plan (RPJP Nasional / RPJPN) is the reference for provincial long-term plans, which in turn guide district/city plans; regional medium-term plans (RPJMD) must refer to both the regional long-term plan and the national medium-term plan (RPJMN). The diagram shows RPJP Nasional guiding RPJMN and the annual RKP; RPJMN guiding ministry strategic plans (RENSTRA) and annual work plans (RENJA); and the parallel regional chain RPJP Daerah -> RPJMD -> RKPD, with Major Projects accelerating RPJMN and RKP delivery. The purpose is to guarantee consistency of development directions and indicators.

**Teks slide (ID):**

```
- RPJP Nasional menjadi acuan dalam penyusunan RPJP Provinsi yang memuat visi, misi, dan arah pembangunan jangka panjang daerah
- RPJP Provinsi menjadi acuan RPJP Kab/kota
- RPJM Daerah yang memuat visi, misi, dan program pembangunan Kepala Daerah mengacu kepada RPJP Daerah dan RPJM Nasional menjadi pedoman dalam penyusunan

Menjamin Konsistensi Arah dan Indikator Pembangunan

RPJP Nasional (Arah dan Indikator Pembangunan) --dipedomani--> RPJMN (Sasaran PN) --dipedomani--> RKP (Sasaran PN)
RPJMN --dipedomani--> RENSTRA (Sasaran Strategis/Program) --dipedomani--> RENJA (Sasaran Program)
RKP --diacu--> RENJA
RPJP Nasional --diacu--> RPJP Daerah (Arah dan Indikator Pembangunan) --dipedomani--> RPJMD (Tujuan dan Sasaran) --dipedomani--> RKPD (Sasaran Program)
RPJMN --dipedomani--> RPJMD
RKP --diacu--> RKPD
Major Project (executive summary) --mempercepat--> RPJMN
Major Project (executive summary dan info memo) --mempercepat--> RKP
```

**Deskripsi visual (ID):** Diagram kotak-panah 3x3: baris atas RENSTRA -> RENJA; baris tengah RPJP Nasional -> RPJMN -> RKP; baris bawah RPJP Daerah -> RPJMD -> RKPD. Panah horizontal berlabel 'Dipedomani', panah vertikal berlabel 'Dipedomani' (ke atas, RPJMN->RENSTRA dan RPJMD->RPJMN) atau 'Diacu' (ke bawah/atas antara nasional-daerah dan RKP-RENJA/RKPD). Dua kotak kuning 'Major Project' dengan panah 'Mempercepat' ke RPJMN dan RKP. Ilustrasi orang mencentang daftar di kiri.

**Visual description (EN):** 3x3 box-and-arrow diagram: top row RENSTRA -> RENJA; middle row RPJP Nasional -> RPJMN -> RKP; bottom row RPJP Daerah -> RPJMD -> RKPD. Horizontal arrows labelled 'Dipedomani' (serves as guideline), vertical arrows labelled 'Dipedomani' or 'Diacu' (referred to) linking national to regional and RKP to RENJA/RKPD. Two yellow 'Major Project' boxes with 'Mempercepat' (accelerates) arrows into RPJMN and RKP. Illustration of a person ticking a checklist on the left.

**Structured data:**

```json
{
  "planning_documents": {
    "RPJP Nasional": "Arah dan Indikator Pembangunan (national long-term plan, 20 yr)",
    "RPJMN": "Sasaran PN (national medium-term plan, 5 yr)",
    "RKP": "Sasaran PN (national annual work plan)",
    "RENSTRA": "Sasaran Strategis/Program (ministry/agency strategic plan)",
    "RENJA": "Sasaran Program (ministry/agency annual work plan)",
    "RPJP Daerah": "Arah dan Indikator Pembangunan (regional long-term plan)",
    "RPJMD": "Tujuan dan Sasaran (regional medium-term plan)",
    "RKPD": "Sasaran Program (regional annual work plan)"
  },
  "edges": [
    [
      "RPJP Nasional",
      "RPJMN",
      "dipedomani"
    ],
    [
      "RPJMN",
      "RKP",
      "dipedomani"
    ],
    [
      "RPJMN",
      "RENSTRA",
      "dipedomani"
    ],
    [
      "RENSTRA",
      "RENJA",
      "dipedomani"
    ],
    [
      "RKP",
      "RENJA",
      "diacu"
    ],
    [
      "RPJP Nasional",
      "RPJP Daerah",
      "diacu"
    ],
    [
      "RPJP Daerah",
      "RPJMD",
      "dipedomani"
    ],
    [
      "RPJMD",
      "RKPD",
      "dipedomani"
    ],
    [
      "RPJMN",
      "RPJMD",
      "dipedomani"
    ],
    [
      "RKP",
      "RKPD",
      "diacu"
    ],
    [
      "Major Project (executive summary)",
      "RPJMN",
      "mempercepat"
    ],
    [
      "Major Project (executive summary dan info memo)",
      "RKP",
      "mempercepat"
    ]
  ]
}
```

**Relationships:**
- RPJP Nasional -> acuan RPJP Provinsi -> acuan RPJP Kab/kota
- RPJM Daerah mengacu RPJP Daerah dan RPJM Nasional
- RPJP Nasional dipedomani RPJMN dipedomani RKP
- RPJMN dipedomani RENSTRA dipedomani RENJA
- RPJP Daerah dipedomani RPJMD dipedomani RKPD
- Major Project mempercepat RPJMN dan RKP


---

## PDF p.22 (slide 20) — Substansi RPJPD Harus Selaras dengan RPJPN

*EN: The Substance of Regional Long-Term Plans (RPJPD) Must Be Aligned with the RPJPN*  
`type: text` `section: central_regional_alignment`

**Summary (EN):** Regional long-term plans (RPJPD) must be aligned with the RPJPN 2025-2045 in three ways: their vision must match Vision Indonesia Emas 2045; their structure must follow the national transformation framework (social, economic and governance transformation; rule-of-law/stability/diplomacy and socio-cultural/ecological resilience as foundations; regional development, green infrastructure and continuity as implementation framework) while focusing on regional transformation suited to local characteristics; and they must target reducing economic, social and governance inequality through transformative means. At minimum an RPJPD must contain main development targets, super-priority transformation efforts, transformation stages, development financing, and implementation rules.

**Teks slide (ID):**

```
1. Visi harus selaras dengan Visi Indonesia Emas 2045, guna mencapai TUJUAN BERSAMA BANGSA

2. Sistematika Substansi RPJPD harus selaras dengan RPJPN 2025-2045: fokus pada TRANSFORMASI DAERAH sesuai dengan karakteristik wilayahnya dan kontribusinya terhadap pembangunan nasional
Transformasi Indonesia: Transformasi Sosial; Transformasi Ekonomi; Transformasi Tata Kelola
Landasan Transformasi: Supremasi Hukum, Stabilitas, dan Ketangguhan Diplomasi; Ketahanan Sosial Budaya dan Ekologi
Kerangka Implementasi Transformasi: Pembangunan Kewilayahan yang Merata dan Berkeadilan; Sarana dan Prasarana yang Berkualitas dan Ramah Lingkungan; Kesinambungan Pembangunan

Paling sedikit RPJPD memuat unsur-unsur:
- Sasaran utama pembangunan
- Upaya transformasi super prioritas
- Tahapan transformasi pembangunan
- Pembiayaan pembangunan
- Kaidah pelaksanaan

3. Agar fokus pada upaya menurunkan ketimpangan ekonomi, sosial, dan tata Kelola; dengan cara-cara yang transformatif, menuju KOHERENSI PEMBANGUNAN INDONESIA
```

**Deskripsi visual (ID):** Tiga poin bernomor; di tengah kotak abu-abu berisi tiga pita hijau (Transformasi Indonesia, Landasan Transformasi, Kerangka Implementasi Transformasi) dengan 8 agenda; panah ke kanan menuju daftar unsur minimum RPJPD. Ilustrasi kupu-kupu warna-warni di kiri.

**Visual description (EN):** Three numbered points; a grey box in the centre with three green bands (Indonesia Transformation, Transformation Foundations, Implementation Framework) listing the 8 agendas; an arrow to the right points to the minimum required RPJPD elements. Colourful butterfly illustration on the left.

**Structured data:**

```json
{
  "rpjpd_alignment_requirements": [
    "Visi selaras dengan Visi Indonesia Emas 2045",
    "Sistematika substansi selaras dengan RPJPN 2025-2045 (8 agenda transformasi), fokus pada transformasi daerah sesuai karakteristik wilayah",
    "Fokus menurunkan ketimpangan ekonomi, sosial, tata kelola secara transformatif"
  ],
  "rpjpd_minimum_elements": [
    "Sasaran utama pembangunan",
    "Upaya transformasi super prioritas",
    "Tahapan transformasi pembangunan",
    "Pembiayaan pembangunan",
    "Kaidah pelaksanaan"
  ]
}
```

**Relationships:**
- RPJPD visi -> selaras Visi Indonesia Emas 2045
- RPJPD sistematika -> mengikuti 8 agenda transformasi RPJPN
- RPJPD minimal memuat 5 unsur


---

## PDF p.23 (slide 21) — Periodisasi RPJPD Harus Selaras dengan Periodisasi RPJPN

*EN: The Period of Regional Long-Term Plans Must Be Aligned with the RPJPN Period*  
`type: diagram` `section: central_regional_alignment`

**Summary (EN):** Regional long-term plans must cover the same 2025-2045 period as the RPJPN, and regional medium-term plans (RPJMD) are required to follow the national medium-term stages: RPJMN 1 (2025-2029), RPJMN 2 (2030-2034), RPJMN 3 (2035-2039) and RPJMN 4 (2040-2045).

**Teks slide (ID):**

```
1. Periode RPJPD harus selaras dengan periode RPJPN: 2025 - 2045
2. Periode Rencana Pembangunan Jangka Menengah (RPJM) Daerah wajib mengikuti periode waktu RPJM Nasional:
TAHAPAN RPJMN
RPJMN 1: 2025-2029
RPJMN 2: 2030-2034
RPJMN 3: 2035-2039
RPJMN 4: 2040-2045
```

**Deskripsi visual (ID):** Dua poin bernomor dan diagram tangga empat anak tangga berwarna (oranye, kuning, hijau, abu-abu) berlabel RPJMN 1-4 dengan periodenya; ilustrasi anak menunjuk ke tangga.

**Visual description (EN):** Two numbered points and a four-step staircase diagram (orange, yellow, green, grey) labelled RPJMN 1-4 with their periods; illustration of a child pointing at the stairs.

**Structured data:**

```json
{
  "rpjpn_period": "2025-2045",
  "rpjmn_stages": [
    {
      "stage": 1,
      "period": "2025-2029"
    },
    {
      "stage": 2,
      "period": "2030-2034"
    },
    {
      "stage": 3,
      "period": "2035-2039"
    },
    {
      "stage": 4,
      "period": "2040-2045"
    }
  ]
}
```

**Relationships:**
- Periode RPJPD = periode RPJPN 2025-2045
- Periode RPJMD wajib mengikuti periode RPJMN


---

## PDF p.24 — Terima Kasih

*EN: Thank You*  
`type: closing` `section: front_matter`

**Summary (EN):** Closing 'thank you' slide of the keynote, Bali, 22 May 2023.

**Teks slide (ID):**

```
MUSRENBANGNAS DALAM RANGKA PENYUSUNAN RPJPN 2025-2045
TERIMA KASIH
Menteri Perencanaan Pembangunan Nasional/ Kepala Badan Perencanaan Pembangunan Nasional
Bali, 22 Mei 2023
```

**Deskripsi visual (ID):** Slide penutup dengan desain sama seperti sampul.

**Visual description (EN):** Closing slide with the same design as the cover.


---

## PDF p.25 — Lampiran

*EN: Appendix*  
`type: section_divider` `section: appendix`

**Summary (EN):** Appendix section divider.

**Teks slide (ID):**

```
LAMPIRAN
```

**Deskripsi visual (ID):** Pembatas bagian dengan logo Garuda, Bappenas, dan ASEAN Indonesia 2023.

**Visual description (EN):** Section divider with Garuda, Bappenas and ASEAN Indonesia 2023 logos.


---

## PDF p.26 (slide 24) — Capaian Sasaran Makro Pembangunan RPJPN 2005-2025 Secara Umum Mengalami Peningkatan

*EN: Achievement of the RPJPN 2005-2025 Macro Development Targets Has Generally Improved*  
`type: table` `section: appendix`

**Summary (EN):** Appendix table of macro outcomes under the previous RPJPN 2005-2025, baseline 2005 vs 2010, 2014, 2019 and 2022: economic growth 5.69% -> 6.22, 5.01, 5.02, 5.31%; inflation 17.11% -> 6.96, 8.36, 2.72, 5.51%; poverty 15.97% -> 13.13, 10.96, 9.22, 9.57%; open unemployment 11.24% -> 7.14, 5.94, 5.23, 5.86%; Gini ratio 0.355 -> 0.378, 0.414, 0.380, 0.381; Human Development Index 72.80 (old method) -> 66.53, 68.90, 71.92, 72.91; fishermen's terms of trade n/a -> 105.56, 104.63, 100.23, 106.45 (base years differ); farmers' terms of trade 101.0 -> 101.80, 102.00, 100.90, 107.33; GHG emission reduction n/a -> 16.40, 19.44, 23.46, 26.87%.

**Teks slide (ID):**

```
Indikator | Baseline (2005) | Capaian 2010 | 2014 | 2019 | 2022
1. Pertumbuhan Ekonomi (%) | 5,69 | 6,22 | 5,01 | 5,02 | 5,31
2. Inflasi (%) | 17,11 | 6,96 | 8,36 | 2,72 | 5,51
3. Tingkat Kemiskinan (%) | 15,97 | 13,13 | 10,96 | 9,22 | 9,57
4. Tingkat Pengangguran Terbuka/TPT (%) | 11,24 | 7,14 | 5,94 | 5,23 | 5,86
5. Rasio Gini (nilai) | 0,355 | 0,378 | 0,414 | 0,380 | 0,381
6. Indeks Pembangunan Manusia/IPM (nilai) | 72,80 b | 66,53 | 68,90 | 71,92 | 72,91
7. Nilai Tukar Nelayan | N/A | 105,56 a | 104,63 a | 100,23 a | 106,45 a
8. Nilai Tukar Petani | 101,0 | 101,80 | 102,00 | 100,90 | 107,33
9. Penurunan Emisi Gas Rumah Kaca/GRK (%) | N/A | 16,40 | 19,44 | 23,46 | 26,87

Keterangan:
a) Capaian 2010 tahun dasar 2007=100; 2014 tahun dasar 2012=100; 2019-2022 tahun dasar 2018=100
b) IPM metode lama
```

**Deskripsi visual (ID):** Tabel 9 indikator makro dengan kolom Baseline 2005 dan capaian 2010, 2014, 2019, 2022 (kolom 2022 dicetak tebal); dua catatan kaki tentang tahun dasar NTN dan metode IPM.

**Visual description (EN):** Table of 9 macro indicators with a 2005 baseline column and achievement columns for 2010, 2014, 2019 and 2022 (2022 in bold); two footnotes on NTN base years and the HDI method.

**Structured data:**

```json
{
  "macro_indicators_rpjpn_2005_2025": {
    "columns": [
      "indicator_id",
      "indicator_en",
      "unit",
      "baseline_2005",
      "2010",
      "2014",
      "2019",
      "2022"
    ],
    "rows": [
      [
        "Pertumbuhan Ekonomi",
        "Economic growth",
        "%",
        5.69,
        6.22,
        5.01,
        5.02,
        5.31
      ],
      [
        "Inflasi",
        "Inflation",
        "%",
        17.11,
        6.96,
        8.36,
        2.72,
        5.51
      ],
      [
        "Tingkat Kemiskinan",
        "Poverty rate",
        "%",
        15.97,
        13.13,
        10.96,
        9.22,
        9.57
      ],
      [
        "Tingkat Pengangguran Terbuka (TPT)",
        "Open unemployment rate",
        "%",
        11.24,
        7.14,
        5.94,
        5.23,
        5.86
      ],
      [
        "Rasio Gini",
        "Gini ratio",
        "index",
        0.355,
        0.378,
        0.414,
        0.38,
        0.381
      ],
      [
        "Indeks Pembangunan Manusia (IPM)",
        "Human Development Index",
        "index",
        72.8,
        66.53,
        68.9,
        71.92,
        72.91
      ],
      [
        "Nilai Tukar Nelayan (NTN)",
        "Fishermen's terms of trade",
        "index",
        null,
        105.56,
        104.63,
        100.23,
        106.45
      ],
      [
        "Nilai Tukar Petani (NTP)",
        "Farmers' terms of trade",
        "index",
        101.0,
        101.8,
        102.0,
        100.9,
        107.33
      ],
      [
        "Penurunan Emisi GRK",
        "GHG emission reduction",
        "%",
        null,
        16.4,
        19.44,
        23.46,
        26.87
      ]
    ],
    "footnotes": {
      "a": "NTN: 2010 base year 2007=100; 2014 base year 2012=100; 2019-2022 base year 2018=100 (applies to NTN values)",
      "b": "IPM 2005 baseline uses the old HDI method (not directly comparable with 2010-2022 new-method values)"
    }
  }
}
```

**Relationships:**
- RPJPN 2005-2025 sasaran makro -> capaian 2010/2014/2019/2022 umumnya meningkat dibanding baseline 2005

